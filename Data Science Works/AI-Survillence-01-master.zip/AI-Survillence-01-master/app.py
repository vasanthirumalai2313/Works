import os
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

import torch
import torch.nn.functional as F
import torchvision.transforms as T
import torchvision.models as models
import numpy as np
import cv2
import time
from ultralytics import YOLO
from deep_sort_realtime.deepsort_tracker import DeepSort
from torch.cuda.amp import autocast
from collections import defaultdict

# Detect system resolution using tkinter
screen_width, screen_height = 1920, 1080
try:
    import tkinter as tk
    root = tk.Tk()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.destroy()
except Exception as e:
    print(f"[WARNING] Could not detect screen resolution. Defaulting to 1920x1080. Error: {e}")

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"[INFO] Using device: {device} - {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU'}")

model = YOLO('yolov8s.pt').to(device)

tracker = DeepSort(
    max_age=120,
    n_init=3,
    nn_budget=100,
    max_iou_distance=0.7,
    max_cosine_distance=0.3
)

embedder_model = models.mobilenet_v2(pretrained=True).features.eval().to(device)

transform = T.Compose([
    T.ToPILImage(),
    T.Resize((128, 128), interpolation=3),
    T.ToTensor(),
    T.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

customer_ids, product_ids = {}, {}
customer_embeddings, product_embeddings = {}, {}
customer_product_map = defaultdict(set)
inactive_customers, picked_products = {}, {}

customer_counter, product_counter = 1, 1
INACTIVE_TIMEOUT = 300

# Setup camera
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    raise RuntimeError("[ERROR] Cannot open camera!")

# Get frame size from video
frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

# Setup video writer
fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter("IQ TechMax1 supermarket_output.avi", fourcc, 20.0, (frame_width, frame_height))

cv2.namedWindow("IQ TechMax Smart Supermarket AI Tracker (Optimized)", cv2.WINDOW_NORMAL)
cv2.resizeWindow("IQ TechMax Smart Supermarket AI Tracker (Optimized)", screen_width, screen_height)

def get_embedding(crop):
    if crop is None or crop.size == 0:
        return None
    try:
        img = transform(crop).unsqueeze(0).to(device)
        with torch.no_grad():
            embedding = embedder_model(img).mean([2, 3])
        return embedding.squeeze()
    except Exception as e:
        print(f"[ERROR] Embedding error: {e}")
        return None

def match_embedding(new_embed, embeddings_dict, threshold=0.7):
    best_match, best_score = None, threshold
    for track_id, embed_list in embeddings_dict.items():
        avg_embed = torch.mean(torch.stack(embed_list), dim=0)
        sim = F.cosine_similarity(new_embed, avg_embed, dim=0).item()
        if sim > best_score:
            best_score, best_match = sim, track_id
    return best_match

def update_embeddings(embeddings_dict, track_id, new_embed, max_size=10):
    embeddings_dict.setdefault(track_id, []).append(new_embed)
    if len(embeddings_dict[track_id]) > max_size:
        embeddings_dict[track_id].pop(0)

print("[INFO] Starting video stream... Press 'q' to quit.")
frame_count = 0

while True:
    ret, frame = cap.read()
    if not ret:
        print("[WARNING] Frame grab failed, stopping.")
        break

    frame_count += 1
    detections = []

    with autocast():
        results = model(frame, device=device)

    for r in results[0].boxes.data.tolist():
        x1, y1, x2, y2, conf, cls = r
        label = model.names[int(cls)]
        if conf > 0.5:
            detections.append(([x1, y1, x2 - x1, y2 - y1], conf, label))

    tracks = tracker.update_tracks(detections, frame=frame)
    person_centers = {}
    active_track_ids = set()
    now = time.time()

    for track in tracks:
        if not track.is_confirmed():
            continue

        track_id = track.track_id
        active_track_ids.add(track_id)
        x1, y1, x2, y2 = map(int, track.to_ltrb())
        label = track.get_det_class()
        cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
        crop = frame[max(0, y1):max(0, y2), max(0, x1):max(0, x2)]
        embed = get_embedding(crop)
        if embed is None:
            continue

        if label == 'person':
            h, w = y2 - y1, x2 - x1
            aspect_ratio = h / (w + 1e-5)
            area = h * w
            if aspect_ratio < 1.2 or area < 5000:
                continue  # Skip hands/partial bodies

            if track_id not in customer_ids:
                matched_id = match_embedding(embed, customer_embeddings)
                if not matched_id:
                    matched_id = match_embedding(embed, {k: [v[1]] for k, v in inactive_customers.items()})
                if matched_id:
                    customer_ids[track_id] = matched_id
                    inactive_customers.pop(matched_id, None)
                else:
                    new_id = f"Customer_{customer_counter:03d}"
                    customer_ids[track_id] = new_id
                    customer_counter += 1

            customer_id = customer_ids[track_id]
            update_embeddings(customer_embeddings, customer_id, embed)
            person_centers[track_id] = (cx, cy)

            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, customer_id, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

        else:
            if track_id not in product_ids:
                matched_id = match_embedding(embed, product_embeddings)
                if matched_id:
                    product_ids[track_id] = matched_id
                else:
                    new_id = f"Product_{product_counter:03d}"
                    product_ids[track_id] = new_id
                    product_counter += 1

            product_id = product_ids[track_id]
            update_embeddings(product_embeddings, product_id, embed)

            for person_track_id, (px, py) in person_centers.items():
                dist = ((cx - px) ** 2 + (cy - py) ** 2) ** 0.5
                if dist < 100 and product_id not in customer_product_map[customer_ids[person_track_id]]:
                    picked_products[track_id] = ((x1, y1, x2, y2), now, product_id)
                    customer_product_map[customer_ids[person_track_id]].add(product_id)

    # Remove inactive customer tracks
    for track_id in list(customer_ids):
        if track_id not in active_track_ids:
            cid = customer_ids[track_id]
            if cid in customer_embeddings:
                avg_embed = torch.mean(torch.stack(customer_embeddings[cid]), dim=0)
                inactive_customers[cid] = (now, avg_embed)
            del customer_ids[track_id]

    # Drop released products
    for pid, (bbox, t, prod_id) in list(picked_products.items()):
        x1, y1, x2, y2 = bbox
        cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
        still_near = any(((cx - px) ** 2 + (cy - py) ** 2) ** 0.5 < 100 for (px, py) in person_centers.values())
        if not still_near:
            for cid in customer_product_map:
                customer_product_map[cid].discard(prod_id)
            del picked_products[pid]

    # Clean up old entries
    inactive_customers = {k: v for k, v in inactive_customers.items() if now - v[0] < INACTIVE_TIMEOUT}
    picked_products = {k: v for k, v in picked_products.items() if now - v[1] < 20}

    for pid, (box, _, label) in picked_products.items():
        x1, y1, x2, y2 = box
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 2)
        cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)

    # Show resized frame and write original to file
    resized_frame = cv2.resize(frame, (screen_width, screen_height))
    cv2.imshow("Smart Supermarket AI Tracker (Optimized)", resized_frame)
    out.write(frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
out.release()
cv2.destroyAllWindows()

print("\n--- Final Pickup Log ---")
for cid, products in customer_product_map.items():
    print(f"{cid} picked: {list(products)}")
