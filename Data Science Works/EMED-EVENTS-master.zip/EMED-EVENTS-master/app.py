import os
import pandas as pd
from difflib import get_close_matches
from flask import Flask, render_template, request, jsonify
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv
from flask_cors import CORS 

# Load environment variables
load_dotenv()


app = Flask(__name__)
CORS(app)

# Load the Excel file
data_path = 'data/Copy of LLM Sample Data_Phase 1.xlsx'
data = pd.ExcelFile(data_path)

# Mapping event types to intended sheet names.
# "course" will be treated as "text-based".
event_sheets = {
    "conference": "Conf. Iperson  Live",
    "webinar": "Conf. Live Webinar",
    "webcast": "Conf. Webcast",
    "journals": "Conf. Journals",
    "text-based": "Conf. Text based",
    "podcast": "Conf. Podcast"
}

# Additional sheets (if needed)
cme_df = data.parse('CME Credits')
specialty_df = data.parse('Professions & Specialties')

# Load Gemini API Key from .env
api_key = os.getenv("GOOGLE_API_KEY")

# Define a system prompt for fallback responses.
system_prompt = (
    "You are a specialized medical event recommendation assistant. "
    "Answer solely using details available in the provided dataset. "
    "If the query mentions 'course', treat it as a text-based event."
)

# AI Model Setup (fallback for non-dataset queries)
ai_model = ChatGoogleGenerativeAI(
    model="gemini-1.5-flash",
    api_key=api_key,
    google_api_key=api_key,
    verbose=True
)

def get_sheet(sheet_name):
    """
    Return the closest matching sheet name from the Excel file.
    """
    available = data.sheet_names
    if sheet_name in available:
        return sheet_name
    matches = get_close_matches(sheet_name, available, n=1, cutoff=0.6)
    if matches:
        return matches[0]
    else:
        raise ValueError(f"Worksheet named '{sheet_name}' not found.")

def extract_city_from_text(query, df):
    """
    Extract a city name from the query by comparing with the 'City'
    column of the provided DataFrame using fuzzy matching.
    """
    if "City" not in df.columns:
        return None
    available_cities = df['City'].dropna().unique().tolist()
    available_cities_lower = [c.lower() for c in available_cities if isinstance(c, str)]
    query_lower = query.lower()
    for city in available_cities_lower:
        if city in query_lower:
            for orig in available_cities:
                if orig.lower() == city:
                    return orig
    matches = get_close_matches(query_lower, available_cities_lower, n=1, cutoff=0.4)
    if matches:
        for orig in available_cities:
            if orig.lower() == matches[0]:
                return orig
    return None

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/recommend", methods=["GET", "POST"])
def recommend():
    if request.method == "POST":
        profession = request.form.get("profession", "").strip()
        specialty = request.form.get("specialty", "").strip()
        event_type = request.form.get("event_type", "").strip().lower()
        if "course" in event_type:
            event_type = "text-based"
        if event_type not in event_sheets:
            return render_template("recommend.html", error="Invalid event type. Please choose from the given options.")
        try:
            sheet_to_use = get_sheet(event_sheets[event_type])
        except ValueError as e:
            return render_template("recommend.html", error=str(e))
        events_df = data.parse(sheet_to_use)
        events_df.fillna('', inplace=True)
        if event_type == "conference":
            country = request.form.get("country", "").strip()
            state = request.form.get("state", "").strip()
            city = request.form.get("city", "").strip()
            filtered = events_df[
                (events_df['Country'].str.contains(country, case=False)) &
                (events_df['State'].str.contains(state, case=False)) &
                (events_df['City'].str.contains(city, case=False))
            ]
        else:
            filtered = events_df[events_df['Specialty'].str.contains(specialty, case=False)]
        if filtered.empty:
            return render_template("results.html", message="No events found for your criteria.", results=None)
        results = filtered.to_dict(orient="records")
        return render_template("results.html", results=results, message=None)
    return render_template("recommend.html")

@app.route("/chat", methods=["GET", "POST"])
def chat():
    response_text = ""
    if request.method == "POST":
        profession = request.form.get("profession", "").strip()
        specialty = request.form.get("specialty", "").strip()
        query = request.form.get("query", "").strip()
        city_field = request.form.get("city", "").strip()  # Optional city from UI
        query_lower = query.lower()
        event_detected = None
        possible_events = list(event_sheets.keys()) + ["course"]
        matches = get_close_matches(query_lower, possible_events, n=1, cutoff=0.4)
        if matches:
            event_detected = matches[0]
            if event_detected == "course":
                event_detected = "text-based"
        if event_detected is None:
            for key in event_sheets.keys():
                if key in query_lower:
                    event_detected = key
                    break
        if event_detected:
            if event_detected == "conference":
                try:
                    conf_sheet = get_sheet(event_sheets["conference"])
                except ValueError as e:
                    response_text = str(e)
                    return render_template("chat.html", response=response_text)
                conf_df = data.parse(conf_sheet)
                conf_df.fillna('', inplace=True)
                city_extracted = extract_city_from_text(query, conf_df)
                if not city_extracted:
                    city_extracted = city_field
                filtered = conf_df[
                    (conf_df['Specialty'].str.contains(specialty, case=False)) &
                    (conf_df['City'].str.contains(city_extracted, case=False))
                ]
                if 'Rating' in filtered.columns:
                    try:
                        filtered['Rating'] = pd.to_numeric(filtered['Rating'], errors='coerce')
                        filtered = filtered.sort_values(by='Rating', ascending=False)
                    except Exception as e:
                        print("Rating conversion error:", e)
                if filtered.empty:
                    response_text = "No conferences found for your query based on our dataset."
                else:
                    lines = []
                    for _, row in filtered.iterrows():
                        lines.append(f"Title: {row['Title']}")
                        lines.append(f"StartDate: {row.get('Start Date', 'N/A')}")
                        lines.append(f"EndDate: {row.get('End Date', 'N/A')}")
                        lines.append(f"Location: {row.get('City', '')}, {row.get('State', '')}, {row.get('Country', '')}")
                        lines.append(f"EventType: {row.get('Event Type', 'N/A')}")
                        lines.append(f"TargetAudience: {row.get('Target Audience', 'N/A')}")
                        lines.append(f"Price: {row.get('Price', 'N/A')}")
                        lines.append(f"CMECredits: {row.get('Credits', 'N/A')}")
                        if 'Rating' in row:
                            lines.append(f"Rating: {row.get('Rating', 'N/A')}")
                        lines.append(f"URL: {row.get('Conference URL', 'N/A')}")
                        lines.append("--------------------------------------------------")
                    response_text = "\n".join(lines)
            else:
                try:
                    sheet_name = get_sheet(event_sheets[event_detected])
                except ValueError as e:
                    response_text = str(e)
                    return render_template("chat.html", response=response_text)
                events_df = data.parse(sheet_name)
                events_df.fillna('', inplace=True)
                filtered = events_df[events_df['Specialty'].str.contains(specialty, case=False)]
                if "City" in events_df.columns:
                    city_extracted = extract_city_from_text(query, events_df)
                    if not city_extracted:
                        city_extracted = city_field
                    if city_extracted:
                        filtered = filtered[filtered['City'].str.contains(city_extracted, case=False)]
                if filtered.empty:
                    response_text = f"No {event_detected} events found for your query based on our dataset."
                else:
                    lines = []
                    for _, row in filtered.iterrows():
                        lines.append(f"Title: {row['Title']}")
                        lines.append(f"StartDate: {row.get('Start Date', 'N/A')}")
                        lines.append(f"EndDate: {row.get('End Date', 'N/A')}")
                        lines.append(f"Location: {row.get('City', '')}, {row.get('State', '')}, {row.get('Country', '')}")
                        lines.append(f"EventType: {row.get('Event Type', 'N/A')}")
                        lines.append(f"TargetAudience: {row.get('Target Audience', 'N/A')}")
                        lines.append(f"Price: {row.get('Price', 'N/A')}")
                        lines.append(f"CMECredits: {row.get('Credits', 'N/A')}")
                        if 'Rating' in row:
                            lines.append(f"Rating: {row.get('Rating', 'N/A')}")
                        if 'Conference URL' in row:
                            lines.append(f"URL: {row.get('Conference URL', 'N/A')}")
                        lines.append("--------------------------------------------------")
                    response_text = "\n".join(lines)
        else:
            final_query = system_prompt + "\nUser query: " + query
            ai_response = ai_model.invoke(final_query)
            if hasattr(ai_response, 'content'):
                response_text = ai_response.content
            else:
                response_text = str(ai_response)
        return render_template("chat.html", response=response_text)
    return render_template("chat.html", response="")

@app.route("/echat", methods=["POST"])
def chat_api():
    data_json = request.get_json()
    profession = data_json.get("profession", "").strip()
    specialty = data_json.get("specialty", "").strip()
    query = data_json.get("query", "").strip()
    city_field = data_json.get("city", "").strip()  # Optional city from JSON

    response_data = []
    query_lower = query.lower()
    event_detected = None
    possible_events = list(event_sheets.keys()) + ["course"]
    
    matches = get_close_matches(query_lower, possible_events, n=1, cutoff=0.4)
    if matches:
        event_detected = matches[0]
        if event_detected == "course":
            event_detected = "text-based"
    if event_detected is None:
        for key in event_sheets.keys():
            if key in query_lower:
                event_detected = key
                break

    if event_detected:
        if event_detected == "conference":
            try:
                conf_sheet = get_sheet(event_sheets["conference"])
            except ValueError as e:
                return jsonify({"response": str(e)})
            conf_df = data.parse(conf_sheet)
            conf_df.fillna('', inplace=True)
            city_extracted = extract_city_from_text(query, conf_df)
            if not city_extracted:
                city_extracted = city_field
            filtered = conf_df[
                (conf_df['Specialty'].str.contains(specialty, case=False)) &
                (conf_df['City'].str.contains(city_extracted, case=False))
            ]
            if 'Rating' in filtered.columns:
                try:
                    filtered['Rating'] = pd.to_numeric(filtered['Rating'], errors='coerce')
                    filtered = filtered.sort_values(by='Rating', ascending=False)
                except Exception as e:
                    print("Rating conversion error:", e)
            if filtered.empty:
                #return jsonify({"response": "No conferences found for your query based on our dataset."})
                return jsonify({"response": []})
            else:
                for _, row in filtered.iterrows():
                    response_data.append({
                        "Title": row['Title'],
                        "StartDate": row.get('Start Date', 'N/A'),
                        "EndDate": row.get('End Date', 'N/A'),
                        "Location": f"{row.get('City', '')}, {row.get('State', '')}, {row.get('Country', '')}",
                        "EventType": row.get('Event Type', 'N/A'),
                        "TargetAudience": row.get('Target Audience', 'N/A'),
                        "Price": row.get('Price', 'N/A'),
                        "CMECredits": row.get('Credits', 'N/A'),
                        "Rating": row.get('Rating', 'N/A') if 'Rating' in row else 'N/A',
                        "URL": row.get('Conference URL', 'N/A')
                    })
        else:
            try:
                sheet_name = get_sheet(event_sheets[event_detected])
            except ValueError as e:
                return jsonify({"response": str(e)})
            events_df = data.parse(sheet_name)
            events_df.fillna('', inplace=True)
            filtered = events_df[events_df['Specialty'].str.contains(specialty, case=False)]
            if "City" in events_df.columns:
                city_extracted = extract_city_from_text(query, events_df)
                if not city_extracted:
                    city_extracted = city_field
                if city_extracted:
                    filtered = filtered[filtered['City'].str.contains(city_extracted, case=False)]
            if filtered.empty:
                #return jsonify({"response": f"No {event_detected} events found for your query based on our dataset."})
                return jsonify({"response": []})
            else:
                for _, row in filtered.iterrows():
                    response_data.append({
                        "Title": row['Title'],
                        "StartDate": row.get('Start Date', 'N/A'),
                        "EndDate": row.get('End Date', 'N/A'),
                        "Location": f"{row.get('City', '')}, {row.get('State', '')}, {row.get('Country', '')}",
                        "EventType": row.get('Event Type', 'N/A'),
                        "TargetAudience": row.get('Target Audience', 'N/A'),
                        "Price": row.get('Price', 'N/A'),
                        "CMECredits": row.get('Credits', 'N/A'),
                        "Rating": row.get('Rating', 'N/A') if 'Rating' in row else 'N/A',
                        "URL": row.get('Conference URL', 'N/A')
                    })
    else:
        final_query = system_prompt + "\nUser query: " + query
        ai_response = ai_model.invoke(final_query)
        if hasattr(ai_response, 'content'):
            return jsonify({"response": ai_response.content})
        else:
            return jsonify({"response": str(ai_response)})

    return jsonify({"response": response_data})

if __name__ == "__main__":
    app.run(debug=True)

