import imaplib
import email
from email.header import decode_header
import os
import re
from bs4 import BeautifulSoup
import dotenv

dotenv.load_dotenv()
# ==== YOUR EMAIL CONFIGURATION (HARDCODED) ====
# EMAIL = "tangiro248@gmail.com"
# APP_PASSWORD = "axsw vjsr kjhv dyhv"  # Gmail App Password
EMAIL = os.getenv("scrap")
APP_PASSWORD = os.getenv("gkey")
IMAP_SERVER = "imap.gmail.com"
DOWNLOAD_FOLDER = "./downloads"

# ==== Create download folder if not exists ====
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

# ==== Connect to Gmail using IMAP ====
mail = imaplib.IMAP4_SSL(IMAP_SERVER)
mail.login(EMAIL, APP_PASSWORD)

# ==== Function to process a mailbox (Inbox or Spam) ====
def process_mailbox(folder_name):
    print(f"\n--- Checking: {folder_name} ---")
    mail.select(folder_name)

    status, messages = mail.search(None, 'UNSEEN')
    email_ids = messages[0].split()
    print(f"Found {len(email_ids)} emails.")

    for i in email_ids[-20:]:  # Check last 20 emails only
        res, msg_data = mail.fetch(i, "(RFC822)")
        for response in msg_data:
            if isinstance(response, tuple):
                msg = email.message_from_bytes(response[1])
                subject, encoding = decode_header(msg["Subject"])[0]
                if isinstance(subject, bytes):
                    subject = subject.decode(encoding or "utf-8", errors="ignore")
                from_ = msg.get("From")
                print(f" Subject: {subject} | From: {from_}")

                # ==== If email has attachments or links ====
                if msg.is_multipart():
                    for part in msg.walk():
                        content_disposition = part.get("Content-Disposition")
                        if content_disposition and "attachment" in content_disposition:
                            filename = part.get_filename()
                            if filename:
                                filepath = os.path.join(DOWNLOAD_FOLDER, filename)
                                with open(filepath, "wb") as f:
                                    f.write(part.get_payload(decode=True))
                                print(f"  Downloaded: {filename}")
                        elif part.get_content_type() == "text/html":
                            html = part.get_payload(decode=True).decode(errors="ignore")
                            soup = BeautifulSoup(html, "html.parser")
                            links = soup.find_all("a", href=True)
                            for link in links:
                                href = link['href']
                                if "resume" in href.lower() or href.lower().endswith(".pdf"):
                                    print(f"  Found resume link: {href}")
                                    # Optionally download using requests or Selenium


# ==== Process Inbox and Spam ====
process_mailbox("inbox")
process_mailbox("[Gmail]/Spam")

# ==== Logout ====
mail.logout()
