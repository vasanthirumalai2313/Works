import imaplib
import email
from email.header import decode_header
import os
import re
import webbrowser
from bs4 import BeautifulSoup

# ==== YOUR EMAIL CONFIGURATION (HARDCODED) ====
EMAIL = "
tangiro248@gmail.com"
APP_PASSWORD =  #Gmail App Password (NOT normal password)
IMAP_SERVER = "imap.gmail.com"
DOWNLOAD_FOLDER = "./downloads"


# ==== Connect to Gmail using IMAP ====
mail = imaplib.IMAP4_SSL(IMAP_SERVER)
mail.login(EMAIL, APP_PASSWORD)
mail.select("inbox")

# ==== Search for emails with attachments ====
status, messages = mail.search(None, 'UNSEEN')
email_ids = messages[0].split()

print(f"Found {len(email_ids)} emails.")

# ==== Create download folder if not exists ====
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

# ==== Loop through last 20 emails ====
for i in email_ids[-20:]:
    res, msg = mail.fetch(i, "(RFC822)")
    for response in msg:
        if isinstance(response, tuple):
            msg = email.message_from_bytes(response[1])
            subject, encoding = decode_header(msg["Subject"])[0]
            if isinstance(subject, bytes):
                subject = subject.decode(encoding or "utf-8")
            from_ = msg.get("From")
            print(f" {subject} from {from_}")

            # ==== If email has attachments ====
            if msg.is_multipart():
                for part in msg.walk():
                    content_disposition = part.get("Content-Disposition")
                    if content_disposition and "attachment" in content_disposition:
                        filename = part.get_filename()
                        if filename:
                            filepath = os.path.join(DOWNLOAD_FOLDER, filename)
                            with open(filepath, "wb") as f:
                                f.write(part.get_payload(decode=True))
                            print(f" Downloaded: {filename}")
                    # ==== Check for links in HTML body ====
                    elif part.get_content_type() == "text/html":
                        html = part.get_payload(decode=True).decode()
                        soup = BeautifulSoup(html, "html.parser")
                        links = soup.find_all("a", href=True)
                        for link in links:
                            href = link['href']
                            if "resume" in href.lower() or href.lower().endswith(".pdf"):
                                print(f" Found resume link: {href}")
                                # You can download this using Selenium or requests here.

# ==== Logout ====
mail.logout()
