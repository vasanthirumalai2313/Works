import cv2
import numpy as np
import json
from datetime import datetime  # Import datetime for timestamps

# Load the DNN model for face detection
prototxt_path = r"C:\face_detection\deploy.prototxt"
model_path = r"C:\face_detection\res10_300x300_ssd_iter_140000.caffemodel"
net = cv2.dnn.readNetFromCaffe(prototxt_path, model_path)

# Capture frames from the camera
cap = cv2.VideoCapture(0)

# Check if the camera opened successfully
if not cap.isOpened():
    print("Error: Could not open camera.")
    exit()

# Get the width and height of the video frame
frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

# Initialize the VideoWriter to save the output video as MP4
timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')  # Format: YYYYMMDD_HHMMSS
output_filename = f'face_detected_{timestamp}.mp4'  # Specify the name of the output file
fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # Codec for MP4 format
out = cv2.VideoWriter(output_filename, fourcc, 20.0, (frame_width, frame_height))

# Create a resizable window
cv2.namedWindow('Face Tracking', cv2.WINDOW_NORMAL)

# List to store trackers for each detected face
trackers = []
total_faces_count = 0  # Variable to count the total number of unique faces detected
is_fullscreen = False  # Track fullscreen state

def is_near(new_bbox, existing_bboxes, distance_threshold=60):
    """Check if the new bounding box is near any existing bounding box."""
    x1, y1, w1, h1 = new_bbox
    center_new = (x1 + w1 / 2, y1 + h1 / 2)
    
    for existing_bbox in existing_bboxes:
        x2, y2, w2, h2 = existing_bbox
        center_existing = (x2 + w2 / 2, y2 + h2 / 2)
        
        # Calculate the Euclidean distance between the centers of the bounding boxes
        distance = ((center_new[0] - center_existing[0]) ** 2 + (center_new[1] - center_existing[1]) ** 2) ** 0.5
        if distance < distance_threshold:
            return True  # New face is near an existing tracker
    return False  # New face is not near any existing tracker

def save_audience_count(count, marker):
    """Save the audience count with timestamp and marker to a JSON file."""
    data = {
        "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        "total_faces_count": count,
        "marker": marker
    }
    
    # Save to a JSON file
    with open('audience_count.json', 'a') as json_file:
        json.dump(data, json_file)
        json_file.write('\n')  # Write a new line for each entry

# Save the start marker when the program begins
save_audience_count(0, 'start')

while True:
    # Read frames from the camera
    ret, img = cap.read()

    # Check if frame is captured properly
    if not ret:
        print("Error: Failed to capture image from camera.")
        break

    # Preprocess the input frame for the Caffe model
    img_resized = cv2.resize(img, (300, 300))  # Resize image to match model's input size
    blob = cv2.dnn.blobFromImage(img_resized, 1.0, (300, 300), (104.0, 177.0, 123.0), swapRB=True)

    # Set the input for the DNN model
    net.setInput(blob)
    
    # Perform face detection using DNN
    detections = net.forward()
    detected_face_bboxes = []  # List to store detected bounding boxes

    # Process detections
    for i in range(detections.shape[2]):
        confidence = detections[0, 0, i, 2]
        if confidence > 0.5:  # Confidence threshold
            box = detections[0, 0, i, 3:7] * np.array([img.shape[1], img.shape[0], img.shape[1], img.shape[0]])
            (startX, startY, endX, endY) = box.astype("int")
            new_face = (startX, startY, endX - startX, endY - startY)
            detected_face_bboxes.append(new_face)

    # Update existing trackers and check if they are still valid
    valid_trackers = []
    existing_bboxes = []  # Store existing bounding boxes for proximity checks

    for tracker in trackers:
        success, bbox = tracker.update(img)
        if success:
            valid_trackers.append(tracker)  # Keep only valid trackers
            existing_bboxes.append(bbox)  # Store existing bounding boxes
            (x, y, w, h) = [int(v) for v in bbox]
            cv2.rectangle(img, (x, y), (x + w, y + h), (255, 255, 0), 2)  # Draw bounding box

    # Update the list of trackers to only include valid ones
    trackers = valid_trackers

    # Check for new faces and add trackers for them
    for new_face in detected_face_bboxes:
        if not is_near(new_face, existing_bboxes):
            # Initialize a new tracker for the newly detected face
            new_tracker = cv2.legacy.TrackerKCF_create()
            new_tracker.init(img, new_face)
            trackers.append(new_tracker)

            # Increment the total faces count if this face is unique
            if new_face not in existing_bboxes:
                total_faces_count += 1  # Increment the total faces count
                save_audience_count(total_faces_count, 'count_update')  # Save count to JSON file

    # Count the number of unique faces being tracked
    face_count = len(trackers)

    # Display the face count and total faces detected on the output window
    cv2.putText(img, f'Live Audience Count: {face_count}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)
    cv2.putText(img, f'Total Audience Detected: {total_faces_count}', (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)

    # Get the current timestamp
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    # Display the timestamp on the frame
    cv2.putText(img, timestamp, (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)

    # Write the frame with the bounding boxes to the output video file
    out.write(img)

    # Resize the window if not fullscreen
    if not is_fullscreen:
        cv2.resizeWindow('Face Tracking', frame_width, frame_height)

    # Display the image in a window
    cv2.imshow('Face Tracking', img)

    # Handle key events
    k = cv2.waitKey(30) & 0xff
    if k == 27:  # Esc key
        save_audience_count(total_faces_count, 'stop')  # Save stop marker
        break
    elif k == ord('f'):  # Press 'f' to toggle fullscreen
        if is_fullscreen:
            cv2.setWindowProperty('Face Tracking', cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_NORMAL)
        else:
            cv2.setWindowProperty('Face Tracking', cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
        is_fullscreen = not is_fullscreen

# Release the camera and close all windows
cap.release()
out.release()  # Release the VideoWriter
cv2.destroyAllWindows()
