# app.py

from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
from chatt import chat, set_user_details  # Import both from your chatbot code
import os
import json

app = Flask(__name__)
CORS(app)

# File path for storing user details in history.json
HISTORY_FILE = os.path.join(os.path.dirname(__file__), "history.json")


@app.route("/")
def index():
    # Ensure templates/ folder has 3index.html
    return render_template("3index.html")


@app.route("/iqbot", methods=["POST"])
def chat_api():
    """Handles user messages and returns chatbot responses."""
    data = request.get_json(force=True)
    user_input = data.get("message", "").strip()
    if not user_input:
        return jsonify({"response": "Please say something first."}), 400

    response = chat(user_input)
    return jsonify({"response": response})


@app.route("/save_user", methods=["POST"])
def save_user():
    """Stores user's name and email in history.json using set_user_details."""
    try:
        data = request.get_json(force=True)
        name = data.get("name", "").strip()
        email = data.get("email", "").strip()

        if not name or not email:
            return jsonify({"error": "Name and email are required."}), 400

        # Use function from chatt.py to store details
        set_user_details(name, email)

        return jsonify({"message": "User data saved successfully.", "data": {"name": name, "email": email}})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
