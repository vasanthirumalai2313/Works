# Genius-TAX-Advisory


file order:

UI : templates/index.html
     static/jpg

