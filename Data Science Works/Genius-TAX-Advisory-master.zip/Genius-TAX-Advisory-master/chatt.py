import os
import json
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain.prompts import ChatPromptTemplate
from langchain.chains import LLMChain
from langchain_community.vectorstores import Chroma

# ————— File paths —————
HISTORY_FILE = "history.json"
SUMMARY_FILE = "summary.json"
USER_INFO_FILE = HISTORY_FILE # Assuming user info is stored in the same history.json

# ————— Store user name/email in history.json —————
def set_user_details(name: str, email: str):
    """Store or update the user's name and email in history.json."""
    if os.path.exists(USER_INFO_FILE):
        with open(USER_INFO_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    else:
        data = []

    # Store name/email separately in the file
    user_info_entry = {"name": name, "email": email}

    # If first element already has name/email, update it
    if data and isinstance(data[0], dict) and "name" in data[0] and "email" in data[0]:
        data[0] = user_info_entry
    else:
        data.insert(0, user_info_entry)

    with open(USER_INFO_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    # Also update in-memory history so it's available for prompts
    memory.history = data

# ————— Load / initialize history —————
def load_history():
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "r") as f:
            return json.load(f)
    return []   # start with empty list of turns

def save_history(history):
    with open(HISTORY_FILE, "w") as f:
        json.dump(history, f, indent=2)

# ————— Load / initialize summary —————
def load_summary():
    if os.path.exists(SUMMARY_FILE):
        with open(SUMMARY_FILE, "r") as f:
            return json.load(f)
    return ""  # start with empty summary

def save_summary(summary):
    with open(SUMMARY_FILE, "w") as f:
        json.dump(summary, f, indent=2)

# ————— In-memory state —————
history = load_history()
overall_summary = load_summary()

# ————— Model & RAG setup —————
load_dotenv()
model      = ChatGoogleGenerativeAI(model="gemini-2.0-flash")
embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
vectordb   = Chroma(
    persist_directory="GeniusTaxAdvisory",
    embedding_function=embeddings
)

# ————— System prompt with separate JSON injections —————
base_system_prompt = """
You are Genius Tax Advisory built, trained and developed by IQ TechMax . Don't greet the user initially, just respond to their query what user ask exactly that's enough. If the user greets, then respond related to greeting.
Your sole responsibility is to provide accurate, helpful and polite responses
about the American taxation system to individuals, startups, small businesses
and large enterprises.

- **Use bold** for each heading.
- Use `-` to start each bullet.
- Output in markdown.

If the user sends a closing greeting at the end of the chat, you should respond with an appropriate farewell.

Do not strip any markdown markers.

You are designed to behave like a human tax advisor and must
communicate in a calm, clear and conversational tone. Your responses must never
confuse the client. Always ensure calculations are accurate and based strictly
on American tax policies, codes and filing rules.

Genius operates exclusively in the United States. Do not
give any information or support related to non-American tax systems. If the
user asks about taxes outside the U.S., politely explain that Genius supports
U.S. taxation only.

Key capabilities:

Answer questions related to federal, state and local taxes
in the U.S.


Explain tax types such as income tax, payroll tax, sales
tax, corporate tax, capital gains tax, property tax, self-employment tax,
excise tax and estate tax.


Advise startups, small businesses, and large corporations
about their tax obligations, deductions, credits, filings and due dates.


Offer guidance on IRS compliance, tax brackets, estimated
taxes and documentation.


Perform precise calculations for income tax, deductions,
percentages, thresholds, credits and penalties when requested by the user.


Use up-to-date contextual data retrieved through the RAG
system from Pinecone.


If the context is insufficient, respond based on general
U.S. tax laws and best practices.


NEVER hallucinate or assume facts. If uncertain, request
clarification or state the limits of your knowledge based on available context.

Behavior guidelines:

If user greets say: "Hi, how can I help you
today?" otherwise do response for the user prompt.

Be concise but detailed enough to address the user’s query
fully.

Always ensure that your tone is professional, patient and
never misleading.

If calculations are required, clearly show the steps and
final result in USD ($).

Do not use emojis, bullet points, or overly casual
language unless the context retrieved shows such tone is required.

Do not ask the user to consult a CPA unless absolutely
necessary or explicitly requested.

Your task is to assist clients accurately, respectfully and
professionally, as a trusted human tax advisor would.

-Only convey the legal law tax process and information of
the American government.

You are now active and ready to assist with American tax
advisory queries. Begin every session with a polite greeting and respond
accordingly using retrieved information, prior summaries and your general
knowledge of U.S. tax law.

- **history.json** (full turn-by-turn chat history in JSON).  
- **summary.json** (a one-paragraph overall summary).

Use both to provide continuous, coherent answers.  

**Scope**  
- Only U.S. federal, state & local taxes.  
- No hallucinations; ask for clarification if uncertain.

Remember to always use the latest chat summary to inform your responses. The response must professional guidance on U.S. tax matters, leveraging both the chat history and the RAG context.

**Conversation History (history.json)**  
{chat_history_json}

**Overall Summary (summary.json)**  
{overall_summary}

"""

rag_prompt = ChatPromptTemplate.from_messages([
    ("system", base_system_prompt),
    ("human", "Context:\n{context}\n\nQuestion: {user_input}")
])

chat_chain = LLMChain(llm=model, prompt=rag_prompt)

# ————— Summarization helper —————
def update_summary(old_summary: str, turn: dict) -> str:
    summarizer_prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a summarizer. Update the one-paragraph summary "
                   "given the old summary and a new turn."),
        ("human", f"Old Summary:\n```{old_summary}```\n\n"
                  f"New Turn:\n```user: {turn['user']}\nassistant: {turn['assistant']}```")
    ])
    summarizer = LLMChain(llm=model, prompt=summarizer_prompt)
    return summarizer.predict()

class ChatMemory:
    def __init__(self, history_file="history.json", summary_file="summary.json"):
        self.history_file = history_file
        self.summary_file = summary_file
        self.history = self._load_json(self.history_file, default=[])
        self.summary = self._load_json(self.summary_file, default="")

    def _load_json(self, path, default):
        if os.path.exists(path):
            with open(path, "r") as f:
                return json.load(f)
        return default

    def save_history(self):
        with open(self.history_file, "w") as f:
            json.dump(self.history, f, indent=2)

    def save_summary(self):
        with open(self.summary_file, "w") as f:
            json.dump(self.summary, f, indent=2)

    def append_turn(self, user, assistant):
        turn = {"user": user, "assistant": assistant}
        self.history.append(turn)
        self.save_history()
        self.summary = update_summary(self.summary, turn)
        self.save_summary()

# Instantiate once at module level:
memory = ChatMemory()

def chat(user_input: str) -> str:
    try:
        # RAG retrieval
        docs = vectordb.similarity_search(user_input, k=4)
        context = "\n\n".join(d.page_content for d in docs)

        # Build prompt
        prompt_vals = {
            "chat_history_json": json.dumps(memory.history, indent=2),
            "overall_summary": memory.summary or "No summary yet.",
            "context": context,
            "user_input": user_input
        }

        # Generate
        assistant_resp = chat_chain.predict(**prompt_vals).strip()

        # Update memory
        memory.append_turn(user_input, assistant_resp)

        return assistant_resp

    except Exception as e:
        return f"An error occurred: {e}"
