import React, { useState, useEffect, useRef } from "react";
import styles from "./remote.module.css";
import {
  MapPin,
  Mic,
  Send,
  AlertTriangle,
  Heart,
  Thermometer,
  Stethoscope,
  Zap,
} from "lucide-react";
import Header from "../../components/Header";

const RemoteDocPWA = () => {
  // Core state management
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    age: "",
    gender: "",
    symptoms: [],
    painLevel: 5,
    location: null,
    photo: null,
    voiceNote: null,
    bodyMap: null,
    emergencyRead: false,
  });

  // Network and app state
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [networkType, setNetworkType] = useState("unknown");
  const [savedReports, setSavedReports] = useState([]);
  const [showWarning, setShowWarning] = useState(false);
  const [warningRead, setWarningRead] = useState(false);

  // Canvas and media refs
  const canvasRef = useRef(null);
  const warningRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const [isRecording, setIsRecording] = useState(false);
  const [hoveredButton, setHoveredButton] = useState(null);

  // Symptom categories
  const symptomCategories = [
    {
      id: "fever",
      name: "Fever/High Temperature",
      icon: <Thermometer className={styles.icon} />,
      urgent: true,
    },
    {
      id: "breathing",
      name: "Breathing Issues",
      icon: <Stethoscope className={styles.icon} />,
      urgent: true,
    },
    {
      id: "chest",
      name: "Chest Pain",
      icon: <Heart className={styles.icon} />,
      urgent: true,
    },
    {
      id: "stomach",
      name: "Stomach Pain",
      icon: <Zap className={styles.icon} />,
      urgent: false,
    },
    {
      id: "headache",
      name: "Severe Headache",
      icon: <AlertTriangle className={styles.icon} />,
      urgent: false,
    },
    {
      id: "injury",
      name: "Injury/Wound",
      icon: <AlertTriangle className={styles.icon} />,
      urgent: false,
    },
  ];

  // Initialize PWA features
  useEffect(() => {
    initializePWAFeatures();
    loadSavedReports();
    setupNetworkMonitoring();
    setupIntersectionObserver();
  }, []);

  const initializePWAFeatures = () => {
    // Register service worker for PWA functionality
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch((err) => {
        console.log("Service Worker registration failed:", err);
      });
    }

    // Setup background sync for offline submissions
    if (
      "serviceWorker" in navigator &&
      "sync" in window.ServiceWorkerRegistration.prototype
    ) {
      navigator.serviceWorker.ready.then((registration) => {
        // Background sync will be handled when form is submitted offline
      });
    }
  };

  const setupNetworkMonitoring = () => {
    // Network Information API
    const updateNetworkInfo = () => {
      setIsOnline(navigator.onLine);

      if ("connection" in navigator) {
        const connection = navigator.connection;
        setNetworkType(connection.effectiveType || "unknown");
      }
    };

    window.addEventListener("online", updateNetworkInfo);
    window.addEventListener("offline", updateNetworkInfo);

    if ("connection" in navigator) {
      navigator.connection.addEventListener("change", updateNetworkInfo);
    }

    updateNetworkInfo();
  };

  const setupIntersectionObserver = () => {
    if (!warningRef.current) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio > 0.8) {
            // User has read at least 80% of the warning
            setTimeout(() => {
              setWarningRead(true);
            }, 3000); // Must view for 3 seconds
          }
        });
      },
      {
        threshold: 0.8,
      }
    );

    observer.observe(warningRef.current);
  };

  const loadSavedReports = () => {
    // Note: In a real PWA, this would use IndexedDB or similar
    // For demo purposes, we'll use a state variable
    setSavedReports([]);
  };

  const saveReport = (report) => {
    const reports = [
      ...savedReports,
      { ...report, id: Date.now(), timestamp: new Date().toISOString() },
    ];
    setSavedReports(reports);
    // In a real PWA, this would save to IndexedDB
  };

  // Geolocation API
  const getCurrentLocation = () => {
    if (!navigator.geolocation) {
      alert("Geolocation not supported");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setFormData((prev) => ({
          ...prev,
          location: {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
          },
        }));
      },
      (error) => {
        console.error("Location error:", error);
        alert(
          "Unable to get location. Please ensure location services are enabled."
        );
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000,
      }
    );
  };

  // Canvas API for body map
  const initializeCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");

    // Draw basic body outline
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = "#333";
    ctx.lineWidth = 2;

    // Simple body outline
    ctx.beginPath();
    // Head
    ctx.arc(150, 80, 40, 0, 2 * Math.PI);
    // Body
    ctx.rect(120, 120, 60, 120);
    // Arms
    ctx.rect(80, 130, 40, 80);
    ctx.rect(180, 130, 40, 80);
    // Legs
    ctx.rect(125, 240, 20, 80);
    ctx.rect(155, 240, 20, 80);
    ctx.stroke();

    // Add click handler for marking pain areas
    canvas.addEventListener("click", (e) => {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      // Draw pain marker
      ctx.fillStyle = "#ff4444";
      ctx.beginPath();
      ctx.arc(x, y, 8, 0, 2 * Math.PI);
      ctx.fill();

      // Save canvas state
      setFormData((prev) => ({
        ...prev,
        bodyMap: canvas.toDataURL(),
      }));
    });
  };

  useEffect(() => {
    if (currentStep === 3) {
      setTimeout(initializeCanvas, 100);
    }
  }, [currentStep]);

  // Photo capture with compression
  const handlePhotoCapture = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    const img = new Image();

    img.onload = () => {
      // Compress based on network type
      let quality = 0.8;
      let maxWidth = 800;

      if (networkType === "2g" || networkType === "slow-2g") {
        quality = 0.3;
        maxWidth = 400;
      } else if (networkType === "3g") {
        quality = 0.5;
        maxWidth = 600;
      }

      const ratio = Math.min(maxWidth / img.width, maxWidth / img.height);
      canvas.width = img.width * ratio;
      canvas.height = img.height * ratio;

      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

      const compressedDataUrl = canvas.toDataURL("image/jpeg", quality);
      setFormData((prev) => ({ ...prev, photo: compressedDataUrl }));
    };

    img.src = URL.createObjectURL(file);
  };

  // Voice recording
  const startVoiceRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      const chunks = [];
      mediaRecorder.ondataavailable = (e) => chunks.push(e.data);

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: "audio/wav" });
        const reader = new FileReader();
        reader.onload = () => {
          setFormData((prev) => ({ ...prev, voiceNote: reader.result }));
        };
        reader.readAsDataURL(blob);
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);

      // Auto-stop after 60 seconds
      setTimeout(() => {
        if (mediaRecorder.state === "recording") {
          stopVoiceRecording();
        }
      }, 60000);
    } catch (err) {
      alert("Unable to access microphone");
    }
  };

  const stopVoiceRecording = () => {
    if (
      mediaRecorderRef.current &&
      mediaRecorderRef.current.state === "recording"
    ) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  // Check for urgent symptoms
  const hasUrgentSymptoms = () => {
    return formData.symptoms.some(
      (symptom) => symptomCategories.find((cat) => cat.id === symptom)?.urgent
    );
  };

  // Form submission
  const handleSubmit = () => {
    if (!warningRead && hasUrgentSymptoms()) {
      setShowWarning(true);
      return;
    }

    const report = {
      ...formData,
      networkType,
      submittedAt: new Date().toISOString(),
      isOnline,
    };

    if (isOnline) {
      // Simulate API submission
      console.log("Submitting report:", report);
      alert("Report submitted successfully!");
    } else {
      // Save for background sync
      saveReport(report);
      alert("Report saved offline. Will sync when connection is restored.");
    }

    // Reset form
    setFormData({
      age: "",
      gender: "",
      symptoms: [],
      painLevel: 5,
      location: null,
      photo: null,
      voiceNote: null,
      bodyMap: null,
      emergencyRead: false,
    });
    setCurrentStep(1);
  };

  const toggleSymptom = (symptomId) => {
    setFormData((prev) => ({
      ...prev,
      symptoms: prev.symptoms.includes(symptomId)
        ? prev.symptoms.filter((s) => s !== symptomId)
        : [...prev.symptoms, symptomId],
    }));
  };

  const getButtonStyle = (base, hover, isHovered, isDisabled = false) => {
    if (isDisabled) return `${base} ${styles.navButtonDisabled}`;
    return isHovered ? `${base} ${hover}` : base;
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div>
            <h2 className={styles.stepTitle}>Basic Information</h2>

            <div className={styles.formGrid}>
              <div className={styles.formGroup}>
                <label className={styles.label}>Age</label>
                <input
                  type="number"
                  value={formData.age}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, age: e.target.value }))
                  }
                  className={styles.input}
                  placeholder="Enter age"
                />
              </div>

              <div className={styles.formGroup}>
                <label className={styles.label}>Gender</label>
                <select
                  value={formData.gender}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, gender: e.target.value }))
                  }
                  className={styles.select}
                >
                  <option value="">Select gender</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>

            <div className={styles.formSection}>
              <button
                onClick={getCurrentLocation}
                className={getButtonStyle(
                  styles.locationButton,
                  styles.locationButtonHover,
                  hoveredButton === "location"
                )}
                onMouseEnter={() => setHoveredButton("location")}
                onMouseLeave={() => setHoveredButton(null)}
              >
                <MapPin className={styles.iconSmall} />
                Get Current Location
              </button>
              {formData.location && (
                <p className={styles.locationSuccess}>
                  ✓ Location captured (±{Math.round(formData.location.accuracy)}
                  m accuracy)
                </p>
              )}
            </div>
          </div>
        );

      case 2:
        return (
          <div>
            <h2 className={styles.stepTitle}>Select Symptoms</h2>

            <div className={styles.symptomGrid}>
              {symptomCategories.map((symptom) => (
                <div
                  key={symptom.id}
                  onClick={() => toggleSymptom(symptom.id)}
                  className={[
                    styles.symptomCard,
                    formData.symptoms.includes(symptom.id) &&
                      styles.symptomCardActive,
                    symptom.urgent && styles.symptomCardUrgent,
                  ]
                    .filter(Boolean)
                    .join(" ")}
                >
                  <div className={styles.symptomCardContent}>
                    {symptom.icon}
                    <span className={styles.symptomName}>{symptom.name}</span>
                    {symptom.urgent && (
                      <AlertTriangle
                        className={`${styles.iconSmall} ${styles.textRed}`}
                      />
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className={styles.formSection}>
              <label className={styles.label}>Pain Level (1-10)</label>
              <input
                type="range"
                min="1"
                max="10"
                value={formData.painLevel}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    painLevel: parseInt(e.target.value),
                  }))
                }
                className={styles.painSlider}
              />
              <div className={styles.painLabels}>
                <span>Mild (1)</span>
                <span className={styles.painCurrent}>
                  Current: {formData.painLevel}
                </span>
                <span>Severe (10)</span>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div>
            <h2 className={styles.stepTitle}>Mark Pain Areas</h2>
            <p className={styles.canvasDescription}>
              Click on the body diagram to mark where you feel pain
            </p>

            <div className={styles.canvasContainer}>
              <canvas
                ref={canvasRef}
                width={300}
                height={400}
                className={styles.canvas}
              />
            </div>

            <button
              onClick={initializeCanvas}
              className={getButtonStyle(
                styles.clearButton,
                styles.clearButtonHover,
                hoveredButton === "clear"
              )}
              onMouseEnter={() => setHoveredButton("clear")}
              onMouseLeave={() => setHoveredButton(null)}
            >
              Clear Marks
            </button>
          </div>
        );

      case 4:
        return (
          <div>
            <h2 className={styles.stepTitle}>Additional Information</h2>

            <div className={styles.formSection}>
              <label className={styles.label}>Photo (Optional)</label>
              <input
                type="file"
                accept="image/*"
                onChange={handlePhotoCapture}
                className={styles.fileInput}
              />
              {formData.photo && (
                <img
                  src={formData.photo}
                  alt="Captured"
                  className={styles.capturedImage}
                />
              )}
            </div>

            <div className={styles.formSection}>
              <label className={styles.label}>Voice Note (Optional)</label>
              <div className={styles.recordingButtons}>
                {!isRecording ? (
                  <button
                    onClick={startVoiceRecording}
                    className={getButtonStyle(
                      { ...styles.recordButton, ...styles.recordButtonStart },
                      styles.recordButtonStartHover,
                      hoveredButton === "record"
                    )}
                    onMouseEnter={() => setHoveredButton("record")}
                    onMouseLeave={() => setHoveredButton(null)}
                  >
                    <Mic className={styles.iconSmall} />
                    Start Recording
                  </button>
                ) : (
                  <button
                    onClick={stopVoiceRecording}
                    className={getButtonStyle(
                      { ...styles.recordButton, ...styles.recordButtonStop },
                      styles.recordButtonStopHover,
                      hoveredButton === "stop"
                    )}
                    onMouseEnter={() => setHoveredButton("stop")}
                    onMouseLeave={() => setHoveredButton(null)}
                  >
                    <Mic className={styles.iconSmall} />
                    Stop Recording
                  </button>
                )}
              </div>
              {formData.voiceNote && (
                <p className={styles.voiceSuccess}>✓ Voice note recorded</p>
              )}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className={styles.container}>
      {/* Header */}

      <Header isOnline={isOnline} networkType={networkType} />
      {/* Progress Bar */}
      <div className={styles.progressLabels}>
        <span>Step {currentStep} of 4</span>
      </div>
      <div className={styles.progressBar}>
        <div
          style={{ width: `${(currentStep / 4) * 100}%` }}
          className={styles.progressFill}
        ></div>
      </div>

      {/* Main Content */}
      <div className={styles.mainContent}>{renderStep()}</div>

      {/* Navigation */}
      <div className={styles.navigation}>
        <button
          disabled={currentStep === 1}
          onClick={() => setCurrentStep((prev) => Math.max(prev - 1, 1))}
          className={getButtonStyle(
            styles.navButton,
            styles.navButtonSecondaryHover,
            hoveredButton === "prev",
            currentStep === 1
          )}
          onMouseEnter={() => setHoveredButton("prev")}
          onMouseLeave={() => setHoveredButton(null)}
        >
          Back
        </button>

        {currentStep < 4 ? (
          <button
            onClick={() => setCurrentStep((prev) => Math.min(prev + 1, 4))}
            className={getButtonStyle(
              styles.navButton,
              styles.navButtonPrimaryHover,
              hoveredButton === "next"
            )}
            onMouseEnter={() => setHoveredButton("next")}
            onMouseLeave={() => setHoveredButton(null)}
          >
            Next
          </button>
        ) : (
          <button
            onClick={handleSubmit}
            className={getButtonStyle(
              styles.navButton,
              styles.navButtonSuccessHover,
              hoveredButton === "submit"
            )}
            onMouseEnter={() => setHoveredButton("submit")}
            onMouseLeave={() => setHoveredButton(null)}
          >
            <Send className={styles.iconSmall} />
            Submit
          </button>
        )}
      </div>
    </div>
  );
};
export default RemoteDocPWA;
