import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import UploadPage from "./screens/UploadPage";
import ChatPage from "./screens/ChatPage";
import ScorePage from "./screens/ScorePage";

const App = () => {
  return (
    <Router>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<UploadPage />} />
          <Route path="/chat" element={<ChatPage />} />
           <Route path="/score" element={<ScorePage />} />
        </Route>
      </Routes>
    </Router>
  );
};

export default App;
