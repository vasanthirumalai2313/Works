import React, { useRef, useState, useEffect } from "react";
import { BACKEND_URL } from "../utils/constants/appConstants";

const ChatBox = () => {
  const [messages, setMessages] = useState([]);
  const [isWaiting, setIsWaiting] = useState(false);
  const inputRef = useRef();
  const chatContainerRef = useRef();



  // ✅ Unchanged: Normal sendMessage function
  const sendMessage = async () => {
    const inputValue = inputRef.current.value;
    if (!inputValue.trim()) return;

    const newMessages = [...messages, { sender: "user", text: inputValue }];
    setMessages(newMessages);
    setIsWaiting(true);
    inputRef.current.value = "";
    inputRef.current.style.height = "auto";

    try {
      const res = await fetch(`${BACKEND_URL}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: inputValue }),
      });

      const data = await res.json();
      setMessages([...newMessages, { sender: "bot", text: data.response }]);
    } catch (err) {
      console.error(err);
      setMessages([
        ...newMessages,
        { sender: "bot", text: "Error from backend" },
      ]);
    } finally {
      setIsWaiting(false);
    }
  };

  useEffect(() => {
    chatContainerRef.current?.scrollTo({
      top: chatContainerRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [messages]);

  return (
    <div style={{ fontFamily: "Arial, sans-serif", border: "2px solid #ccc", borderRadius: "12px", padding: "10px", background: "#f9f9f9" }}>


      <div
        ref={chatContainerRef}
        style={{
          height: "400px",
          overflowY: "auto",
          padding: "10px",
          marginBottom: "15px",
          display: "flex",
          flexDirection: "column",
          gap: "10px",
          backgroundColor: "#fff",
          borderRadius: "10px",
          border: "1px solid #ddd",
          wordWrap: "break-word",
        }}
      >
        {messages.map((msg, index) => (
          <div
            key={index}
            style={{
              alignSelf: msg.sender === "user" ? "flex-end" : "flex-start",
              backgroundColor: msg.sender === "user" ? "#DCF8C6" : "#E3E3E3",
              color: "#333",
              padding: "10px 15px",
              borderRadius: "20px",
              maxWidth: "70%",
              whiteSpace: "pre-wrap",
              overflowWrap: "break-word",
              wordBreak: "break-word",
              boxShadow: "0 2px 5px rgba(0, 0, 0, 0.1)",
              fontFamily: "inherit",
            }}
          >
            <strong style={{ display: "block", fontSize: "0.8em" }}>
              {msg.sender === "user" ? "You" : "Bot"}
            </strong>
            {msg.text}
          </div>
        ))}
      </div>

      <div style={{ display: "flex", gap: "10px" }}>
        <textarea
          ref={inputRef}
          placeholder="Type or paste your message..."
          disabled={isWaiting}
          onInput={(e) => {
            e.target.style.height = "auto";
            e.target.style.height = Math.min(e.target.scrollHeight, 150) + "px";
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              e.target.style.height = "auto";
              sendMessage();
            }
          }}
          style={{
            flex: 1,
            fontSize: "16px",
            lineHeight: "20px",
            padding: "10px",
            borderRadius: "8px",
            border: "1px solid #ccc",
            resize: "none",
            overflowY: "auto",
            maxHeight: "150px",
            minHeight: "40px",
            whiteSpace: "pre-wrap",
            wordBreak: "break-word",
            boxSizing: "border-box",
          }}
        />

        <button
          onClick={sendMessage}
          disabled={isWaiting}
          style={{
            padding: "10px 20px",
            backgroundColor: "#4CAF50",
            color: "white",
            border: "none",
            borderRadius: "8px",
            cursor: "pointer",
            maxHeight: "40px",
            margin: "auto",
          }}
        >
          Send
        </button>
      </div>
    </div>
  );
};


export default ChatBox