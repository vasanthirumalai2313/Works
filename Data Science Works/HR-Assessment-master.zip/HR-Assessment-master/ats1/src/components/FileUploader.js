import React, { useState } from "react";

const FileUploader = ({ label, endpoint, type = "file" }) => {
  const [files, setFiles] = useState([]);
  const [text, setText] = useState(""); // for text input
  const [message, setMessage] = useState("");

  const handleUpload = async () => {
    if (type === "file" && !files.length) {
      alert("Please select a file.");
      return;
    }
    if (type === "text" && text.trim() === "") {
      alert("Please enter some text.");
      return;
    }

    let body;
    let headers = {};

    if (type === "file") {
      const formData = new FormData();
      formData.append("file", files[0]);
      body = formData;
    } else {
      body = JSON.stringify({ job_description: text });
      headers["Content-Type"] = "application/json";
    }

    try {
      const res = await fetch(endpoint, {
        method: "POST",
        body,
        headers,
      });

      const data = await res.json();
      setMessage(data.message || "Upload successful");
    } catch (err) {
      console.error(err);
      setMessage("Upload failed");
    }
  };

  return (
    <div style={styles.uploader}>
      <h3>{label}</h3>

      {type === "file" ? (
        <input
          type="file"
          multiple
          onChange={(e) => setFiles(Array.from(e.target.files))}
          style={styles.input}
        />
      ) : (
        <textarea
          placeholder="Paste job description here..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          style={styles.textarea}
        />
      )}

      <button onClick={handleUpload} style={styles.button}>
        Upload
      </button>
      <p style={styles.status}>{message}</p>
    </div>
  );
};

const styles = {
  uploader: {
    border: "1px solid #ddd",
    borderRadius: "8px",
    padding: "20px",
    background: "#fefefe",
    boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
    marginBottom: "20px",
  },
  input: {
    display: "block",
    marginTop: "10px",
    marginBottom: "10px",
  },
  textarea: {
    width: "100%",
    minHeight: "120px",
    padding: "10px",
    fontSize: "14px",
    borderRadius: "4px",
    border: "1px solid #ccc",
    marginTop: "10px",
    marginBottom: "10px",
  },
  button: {
    padding: "8px 16px",
    backgroundColor: "#4f46e5",
    color: "white",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
  },
  status: {
    marginTop: "10px",
    color: "#333",
  },
};

export default FileUploader;