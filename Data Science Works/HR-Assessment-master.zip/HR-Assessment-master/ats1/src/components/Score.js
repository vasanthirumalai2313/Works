import React, { useEffect, useState, useRef } from "react";
import html2pdf from "html2pdf.js";
import { BACKEND_URL } from "../utils/constants/appConstants";

const DUMMY_DATA = {
  name: "cehbrlviebtih",
  score: "38",
};

const Score = () => {
  const [scoreData, setScoreData] = useState();
  const [loading,setLoading]=useState(false)
  const scoreRef = useRef();

  const getScore = async () => {
    setLoading(true)
    try {
      const response = await fetch(BACKEND_URL + "/start-evaluation", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
      const data = await response.json();
      console.log(data)
      setScoreData(data);
      console.log(data);
    } catch (err) {
      console.log("err", err);
    }finally{
      setLoading(false)
    }
  };

  const downloadPDF = () => {
    const element = scoreRef.current;

    const opt = {
      margin: 0.5,
      filename: "score.pdf",
      image: { type: "jpeg", quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: "in", format: "letter", orientation: "portrait" },
    };

    html2pdf().set(opt).from(element).save();
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <button onClick={getScore}>Get score</button>
      {scoreData && (
        <>
          <div ref={scoreRef}>
            <h2>Candidate Evaluation</h2>
            
            <p>
              <strong>Overall Eligibility Percentage:</strong>{" "}
              {scoreData.evaluation_result.overall_eligibility_percentage}%
            </p>

            <h3>Detailed Scores</h3>
            {Object.entries(scoreData.evaluation_result.detailed_scores).map(
              ([category, data]) => (
                <div key={category}>
                  <h4>
                    {category
                      .replace(/_/g, " ")
                      .replace(/\b\w/g, (c) => c.toUpperCase())}
                  </h4>
                  <p>
                    <strong>Score:</strong> {data.score}
                  </p>
                  <p>
                    <strong>Evidence:</strong> {data.evidence}
                  </p>
                  <p>
                    <strong>Gaps:</strong> {data.gaps}
                  </p>
                </div>
              )
            )}

            <h3>Key Strengths</h3>
            <ul>
              {scoreData.evaluation_result.key_strengths.map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>

            <h3>Key Weaknesses</h3>
            <ul>
              {scoreData.evaluation_result.key_weaknesses.map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>

            <h3>Hiring Recommendation</h3>
            <p>
              <strong>Decision:</strong>{" "}
              {scoreData.evaluation_result.hiring_recommendation.decision}
            </p>
            <p>
              <strong>Confidence Level:</strong>{" "}
              {
                scoreData.evaluation_result.hiring_recommendation
                  .confidence_level
              }
            </p>
            <p>
              <strong>Reasoning:</strong>{" "}
              {scoreData.evaluation_result.hiring_recommendation.reasoning}
            </p>

            <h3>Detailed Assessment</h3>
            <p>{scoreData.evaluation_result.detailed_assessment}</p>

            <p>
              <strong>Message:</strong> {scoreData.message}
            </p>
          </div>

          <button
            onClick={downloadPDF}
            style={{ marginTop: "10px", width: "10%" }}
          >
            Download PDF
          </button>
        </>
      )}
      {loading &&<h3>loading...</h3>}
    </div>
  );
};

export default Score;