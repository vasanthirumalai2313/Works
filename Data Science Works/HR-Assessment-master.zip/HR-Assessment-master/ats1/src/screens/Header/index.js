import React from "react";
import { Link } from "react-router-dom";

function Header() {
  return (
    <div style={{ display: "flex", justifyContent: "center", gap: 20 }}>
      <Link to="/">uploads</Link>
      <Link to="/chat">Chat</Link>
       <Link to="/score">Score</Link>
    </div>
  );
}

export default Header;
