import React from "react";
import Score from "../components/Score";

function ScorePage() {
  return (
    <div style={{ padding: "20px" }}>
      <Score />
    </div>
  );
}

export default ScorePage;