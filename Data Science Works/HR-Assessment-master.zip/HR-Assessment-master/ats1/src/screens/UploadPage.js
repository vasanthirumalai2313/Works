import React from "react";
import FileUploader from "../components/FileUploader";
import { BACKEND_URL } from "../utils/constants/appConstants";

const UploadPage = () => {
  return (
    <div style={styles.container}>
      <h2 style={styles.heading}>Upload Multiple Files</h2>

      <FileUploader
        label="Upload Resumes (Multiple)"
        endpoint={BACKEND_URL + "/setup/resume"}
      />
      <FileUploader
        label="Upload Job Descriptions (Text)"
        endpoint={BACKEND_URL + "/setup/jobdescription"}
        type="text" // <-- pass type prop
      />
      {/* <FileUploader
        label="Upload Knowledge Base Files (Multiple)"
        endpoint={BACKEND_URL + "/upload/kb"}
      /> */}
    </div>
  );
};

const styles = {
  container: {
    padding: "40px",
    maxWidth: "600px",
    margin: "0 auto",
    backgroundColor: "#f9fafb",
    borderRadius: "10px",
  },
  heading: {
    textAlign: "center",
    marginBottom: "30px",
    color: "#111827",
  },
};

export default UploadPage;
