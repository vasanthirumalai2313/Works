import json

def convert_json_array_txt_to_conversation(input_path, output_path):
    with open(input_path, 'r', encoding='utf-8') as f:
        data = f.read().strip()

    try:
        chat_data = json.loads(data)
    except Exception as e:
        print(f"Failed to parse JSON. Error: {e}")
        return

    conversation_lines = []

    for entry in chat_data:
        user = entry.get("user", "").strip()
        bot = entry.get("bot", "").strip()

        if user:
            conversation_lines.append(f"Candidate: {user}")
        if bot:
            conversation_lines.append(f"Interviewer: {bot}")
        
        conversation_lines.append("")  # blank line for readability

    with open(output_path, 'w', encoding='utf-8') as out:
        out.write("\n".join(conversation_lines))

    print(f"Formatted conversation saved to: {output_path}")


#  Usage
convert_json_array_txt_to_conversation("chat_nhistory.txt", "formatted_chat.txt")
