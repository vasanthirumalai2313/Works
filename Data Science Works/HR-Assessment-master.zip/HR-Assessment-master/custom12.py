import os
import json
import time
import requests
from dotenv import load_dotenv
from pinecone import Pinecone, ServerlessSpec
import pdfplumber
from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import tempfile

# Load environment variables
load_dotenv()

PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
INDEX_NAME = "iq-bot-demo1"
CHAT_HISTORY_FILE = "chat_nhistory.txt"
SUMMARY_FILE = "chat_nsummary.txt"
ASKED_QUESTIONS_FILE = "asked_questions.json"
INTERVIEW_STATE_FILE = "interview_state.json"

# Initialize FastAPI
app = FastAPI(title="IQ-Techmax HR Agent API", version="1.0.0")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure this properly in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Pinecone client
pc = Pinecone(api_key=PINECONE_API_KEY)

# Global variables to store session data
session_data = {
    "jd_content": "",
    "resume_content": "",
    "session_initialized": False
}

def initialize_pinecone_index():
    if INDEX_NAME not in pc.list_indexes().names():
        pc.create_index(
            name=INDEX_NAME,
            dimension=768,
            metric="cosine",
            spec=ServerlessSpec(cloud="aws", region="us-east-1")
        )
    return pc.Index(INDEX_NAME)

index = initialize_pinecone_index()

# === Resume parsing functionality ===

def parse_pdf_resume(pdf_path):
    with pdfplumber.open(pdf_path) as pdf:
        full_text = ''
        for page in pdf.pages:
            text = page.extract_text()
            if text:
                full_text += text + '\n'
    return full_text

# === File operations ===

def load_json_file(file_path):
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return []
    return []

def save_json_file(file_path, data):
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

# === Chat history management ===

def load_chat_history():
    return load_json_file(CHAT_HISTORY_FILE)

def append_chat_history(user_query, bot_response):
    history = load_chat_history()
    current_index = history[-1]["index"] + 1 if history else 1
    history.append({
        "index": current_index,
        "user": user_query.strip(),
        "bot": bot_response.strip(),
        "timestamp": time.time()
    })
    save_json_file(CHAT_HISTORY_FILE, history)

# === Summary management ===

def load_summary():
    return load_json_file(SUMMARY_FILE)

def append_summary(new_summary_point):
    if not new_summary_point or new_summary_point.strip() == "":
        return
    summary = load_summary()
    current_index = summary[-1]["index"] + 1 if summary else 1
    summary.append({
        "index": current_index,
        "summary": new_summary_point.strip(),
        "timestamp": time.time()
    })
    save_json_file(SUMMARY_FILE, summary)

# === Question tracking system ===

def load_asked_questions():
    return load_json_file(ASKED_QUESTIONS_FILE)

def save_asked_question(question_category, question_text):
    if not question_text or "?" not in question_text:
        return
    
    asked_questions = load_asked_questions()
    asked_questions.append({
        "category": question_category,
        "question": question_text.strip(),
        "timestamp": time.time()
    })
    save_json_file(ASKED_QUESTIONS_FILE, asked_questions)

def get_asked_questions_summary():
    asked_questions = load_asked_questions()
    if not asked_questions:
        return "No questions asked yet."
    
    categories = {}
    for q in asked_questions:
        category = q.get("category", "general")
        if category not in categories:
            categories[category] = []
        categories[category].append(q["question"])
    
    summary = "QUESTIONS ALREADY ASKED:\n"
    for category, questions in categories.items():
        summary += f"{category.upper()}: "
        for i, q in enumerate(questions, 1):
            summary += f"{i}.{q[:50]}... " if len(q) > 50 else f"{i}.{q} "
        summary += "\n"
    
    return summary

# === Interview state management ===

def load_interview_state():
    state = load_json_file(INTERVIEW_STATE_FILE)
    if not state:
        return {
            "current_phase": "introduction",
            "topics_covered": [],
            "skills_assessed": [],
            "question_count": 0,
            "max_questions": 20,
            "awaiting_clarification": False,
            "last_question_topic": ""
        }
    return state

def update_interview_state(phase=None, topic=None, skill=None, awaiting_clarification=False):
    state = load_interview_state()
    
    if phase:
        state["current_phase"] = phase
    if topic and topic not in state["topics_covered"]:
        state["topics_covered"].append(topic)
    if skill and skill not in state["skills_assessed"]:
        state["skills_assessed"].append(skill)
    
    state["awaiting_clarification"] = awaiting_clarification
    state["question_count"] = len(load_asked_questions())
    save_json_file(INTERVIEW_STATE_FILE, state)
    return state

# === Embedding and context retrieval ===

def get_embedding(query):
    return [0.0] * 768  # Dummy embedding - replace with actual embedding service

def query_pinecone(query):
    vector = get_embedding(query)
    result = index.query(vector=vector, top_k=5, include_metadata=True)
    context = []
    if "matches" in result:
        for match in result["matches"]:
            metadata = match.get("metadata", {})
            if "text" in metadata:
                context.append(metadata["text"])
    return "\n".join(context)

# === Gemini API interaction ===

def get_gemini_response(prompt, retries=3, backoff=2):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={GOOGLE_API_KEY}"
    headers = {"Content-Type": "application/json"}
    data = {"contents": [{"parts": [{"text": prompt}]}]}

    for attempt in range(retries):
        try:
            response = requests.post(url, headers=headers, json=data)
            if response.status_code == 503:
                print(f"Gemini 503 error, attempt {attempt + 1} of {retries}. Retrying...")
                time.sleep(backoff * (attempt + 1))
                continue
            response.raise_for_status()
            result = response.json()
            return result['candidates'][0]['content']['parts'][0]['text']
        except requests.exceptions.RequestException as e:
            print(f"Gemini API Error: {e}")
            time.sleep(backoff * (attempt + 1))

    print("Gemini API failed after retries.")
    return None

# === Bot Conversation Initiation Function ===

async def initiate_bot_conversation():
    """Generate and save the initial bot greeting after parsing resume and JD"""
    try:
        initial_greeting_prompt = f"""You are Anusha, an IQ-Techmax HR Interviewer. You have just finished analyzing the candidate's resume and job description. Now start the interview conversation with a personalized, professional greeting.

CANDIDATE RESUME: {session_data["resume_content"]}

JOB DESCRIPTION: {session_data["jd_content"]}

Your task is to start the interview conversation with a personalized, professional greeting. Extract the candidate's name from their resume and greet them warmly.

RESPONSE FORMAT (JSON):
{{
  "response": "[Your personalized greeting and introduction]",
  "updatedSummary": "Interview session started with candidate introduction",
  "questionCategory": "introduction",
  "validAnswer": true
}}

Example greeting structure:
- Greet the candidate by name
- Introduce yourself as Anusha from IQ-Techmax
- Mention you're the interviewer
- Ask them to introduce themselves
- Keep it warm and professional

Generate the greeting now."""

        response_text = get_gemini_response(initial_greeting_prompt)
        
        if response_text:
            try:
                cleaned_response = response_text.replace("```json", "").replace("```", "").strip()
                response_json = json.loads(cleaned_response)
                
                bot_answer = response_json.get("response", "").strip()
                new_summary_point = response_json.get("updatedSummary", "").strip()
                question_category = response_json.get("questionCategory", "introduction")
                
                # Update interview state for introduction phase
                update_interview_state(
                    phase=question_category,
                    topic=question_category,
                    awaiting_clarification=False
                )
                
                if new_summary_point:
                    append_summary(new_summary_point)
                
                # Save as bot initiating the conversation (empty user query for greeting)
                append_chat_history("", bot_answer)
                
                # Save the greeting as a question
                if "?" in bot_answer:
                    save_asked_question(question_category, bot_answer)
                
                # Mark session as initialized
                session_data["session_initialized"] = True
                
                print(f"Bot initiated conversation: {bot_answer}")
                
            except json.JSONDecodeError as e:
                print(f"JSON Error in greeting: {e}")
                fallback_greeting = "Hello! I'm Anusha from IQ-Techmax, and I'll be your interviewer today. Could you please introduce yourself?"
                append_chat_history("", fallback_greeting)
                session_data["session_initialized"] = True
                print(f"Bot initiated conversation (fallback): {fallback_greeting}")
                
        else:
            fallback_greeting = "Hello! I'm Anusha from IQ-Techmax, and I'll be your interviewer today. Could you please introduce yourself?"
            append_chat_history("", fallback_greeting)
            session_data["session_initialized"] = True
            print(f"Bot initiated conversation (fallback): {fallback_greeting}")
            
    except Exception as e:
        print(f"Error initiating bot conversation: {e}")
        fallback_greeting = "Hello! I'm Anusha from IQ-Techmax, and I'll be your interviewer today. Could you please introduce yourself?"
        append_chat_history("", fallback_greeting)
        session_data["session_initialized"] = True

def generate_response(query, source, name, role, description, resume_content="", jd_content=""):
    summary_data = load_summary()
    chat_history_data = load_chat_history()
    asked_questions_summary = get_asked_questions_summary()
    interview_state = load_interview_state()

    # Create chat history context (last 8 exchanges)
    chat_context = ""
    if chat_history_data:
        chat_context = "CONVERSATION:\n"
        for item in chat_history_data[-8:]:
            chat_context += f"Q: {item['user']}\nA: {item['bot']}\n"
    
    current_summary = "\n".join([f"{item['summary']}" for item in summary_data[-5:]])
    
    system_prompt = f"""You are {name}, an {role}. Conduct professional technical interviews for the position mention in the {jd_content}.
Conduct the interview for the job role mentioned in the job description not in the resume. Ask the main question and try to complete the interview process.
CRITICAL RULES:
1. NEVER repeat questions already asked
2. ONLY ask about skills/technologies present in BOTH resume AND job description
3. VALIDATE answers - if irrelevant/nonsensical, ask for clarification
4. ASK only ONE question at a time
5. Move logically through interview phases
6. Avoid asking questions on topics the candidate is clearly unfamiliar with (unless probing for learning intent or adaptability).

{asked_questions_summary}

ANSWER VALIDATION:
- If answer doesn't relate to question topic, respond: "That doesn't seem related to [topic]. Could you provide a specific technical example?"
- If answer is too vague, ask: "Can you be more specific about [specific aspect]?"
- If answer seems fabricated, probe deeper: "Could you explain the technical details of how you implemented that?"
- If candidate can't answer for the same question more than 2 times just ignore that question and more on to next question silently.

QUESTION STRATEGY:
1. Introduction: Verify candidate identity and role interest
2. Technical Skills: Ask ONLY about skills in both resume+JD
3. Projects: Discuss specific projects from resume
4. Problem-solving: Scenario-based questions
5. Closing: Wrap up professionally

SKILL MATCHING RULE:
Before asking about any technology/skill:
- Check if it exists in candidate's resume
- If NOT in resume but in JD, skip it or ask: "I notice [skill] is required for this role but not mentioned in your resume. Do you have any experience with it?"

CONCLUSION:
- Never tell whether the candidate is selected or not.If they ask just mention that HR will contact you regarding the next process.
- If the candidate like to stop the interview ask them and terminate the CONVERSATION.
- When interview complete: "OK, thank you. Our HR team will contact you regarding the next steps."


RESPONSE FORMAT (JSON):
{{
  "response": "[Your response/question]",
  "updatedSummary": "[What was learned/assessed]",
  "questionCategory": "[introduction/technical/experience/behavioral/closing]",
  "validAnswer": "[true/false - was last answer valid]"
}}

CONTEXT:
Resume: {resume_content}
JD: {jd_content}
{chat_context}
Progress: {current_summary}
User: {query}

Awaiting Clarification: {interview_state.get('awaiting_clarification', False)}
"""

    response_text = get_gemini_response(system_prompt)

    if response_text:
        try:
            cleaned_response = response_text.replace("```json", "").replace("```", "").strip()
            response_json = json.loads(cleaned_response)
            
            bot_answer = response_json.get("response", "").strip()
            new_summary_point = response_json.get("updatedSummary", "").strip()
            question_category = response_json.get("questionCategory", "general")
            valid_answer = response_json.get("validAnswer", True)
            
            # Update interview state
            awaiting_clarification = not valid_answer if "?" in bot_answer else False
            update_interview_state(
                phase=question_category,
                topic=question_category,
                awaiting_clarification=awaiting_clarification
            )
            
            if new_summary_point:
                append_summary(new_summary_point)
            append_chat_history(query, bot_answer)
            
            # Save question if it's a new question
            if "?" in bot_answer:
                save_asked_question(question_category, bot_answer)
            
            return bot_answer
            
        except json.JSONDecodeError as e:
            print(f"JSON Error: {e}")
            fallback_response = "Could you please elaborate on your previous answer with more technical details?"
            append_chat_history(query, fallback_response)
            return fallback_response
        except Exception as e:
            print(f"Error: {e}")
            append_chat_history(query, response_text)
            return response_text
    else:
        error_response = "I'm having technical difficulties. Could you please repeat your last response?"
        append_chat_history(query, error_response)
        return error_response

# === Pydantic Models ===

class JobDescriptionRequest(BaseModel):
    job_description: str

class ChatRequest(BaseModel):
    message: str

class ChatResponse(BaseModel):
    response: str
    session_initialized: bool

class SetupResponse(BaseModel):
    message: str
    jd_received: bool
    resume_received: bool
    session_ready: bool

class RootResponse(BaseModel):
    message: str

class SessionStatusResponse(BaseModel):
    jd_received: bool
    resume_received: bool
    session_ready: bool
    session_initialized: bool
    questions_asked: int
    interview_phase: str

class SessionResetResponse(BaseModel):
    message: str

class ChatHistoryResponse(BaseModel):
    history: List[dict]

class ChatSummaryResponse(BaseModel):
    summary: List[dict]

class InterviewStateResponse(BaseModel):
    state: dict

# === API Endpoints ===

@app.get("/", response_model=RootResponse)
async def root():
    return RootResponse(message="IQ-Techmax HR Agent API is running!")

@app.post("/setup/jobdescription", response_model=SetupResponse)
async def set_job_description(request: JobDescriptionRequest):
    session_data["jd_content"] = request.job_description.strip()
    
    # Check if both resume and JD are ready, then start the conversation
    if session_data["jd_content"] and session_data["resume_content"] and not session_data["session_initialized"]:
        await initiate_bot_conversation()
    
    return SetupResponse(
        message="Job description received successfully",
        jd_received=True,
        resume_received=bool(session_data["resume_content"]),
        session_ready=bool(session_data["jd_content"] and session_data["resume_content"])
    )

@app.post("/setup/resume", response_model=SetupResponse)
async def upload_resume(file: UploadFile = File(...)):
    if not file.filename.endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Only PDF files are supported")
    
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp_file:
            content = await file.read()
            tmp_file.write(content)
            tmp_file.flush()
            
            session_data["resume_content"] = parse_pdf_resume(tmp_file.name)
            
        os.unlink(tmp_file.name)
        
        # Check if both resume and JD are ready, then start the conversation
        if session_data["jd_content"] and session_data["resume_content"] and not session_data["session_initialized"]:
            await initiate_bot_conversation()
        
        return SetupResponse(
            message="Resume uploaded and parsed successfully",
            jd_received=bool(session_data["jd_content"]),
            resume_received=True,
            session_ready=bool(session_data["jd_content"] and session_data["resume_content"])
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing resume: {str(e)}")

@app.post("/chat", response_model=ChatResponse)
async def chat_with_agent(request: ChatRequest):
    if not session_data["jd_content"] or not session_data["resume_content"]:
        raise HTTPException(
            status_code=400, 
            detail="Session not ready. Please upload job description and resume first."
        )
    
    try:
        # Check if this is the first interaction (no chat history exists)
        chat_history = load_chat_history()
        
        if not chat_history and not session_data["session_initialized"]:
            # This is the first interaction - bot should start the conversation
            initial_greeting_prompt = f"""You are Anusha, an IQ-Techmax HR Interviewer. This is the very first interaction with the candidate. 

CANDIDATE RESUME: {session_data["resume_content"]}

JOB DESCRIPTION: {session_data["jd_content"]}

Your task is to start the interview conversation with a personalized, professional greeting. Extract the candidate's name from their resume and greet them warmly.

RESPONSE FORMAT (JSON):
{{
  "response": "[Your personalized greeting and introduction]",
  "updatedSummary": "Interview session started with candidate introduction",
  "questionCategory": "introduction",
  "validAnswer": true
}}

Example greeting structure:
- Greet the candidate by name
- Introduce yourself as Anusha from IQ-Techmax
- Mention you're the interviewer
- Ask them to introduce themselves
- Keep it warm and professional

Generate the greeting now."""

            response_text = get_gemini_response(initial_greeting_prompt)
            
            if response_text:
                try:
                    cleaned_response = response_text.replace("```json", "").replace("```", "").strip()
                    response_json = json.loads(cleaned_response)
                    
                    bot_answer = response_json.get("response", "").strip()
                    new_summary_point = response_json.get("updatedSummary", "").strip()
                    question_category = response_json.get("questionCategory", "introduction")
                    
                    # Update interview state for introduction phase
                    update_interview_state(
                        phase=question_category,
                        topic=question_category,
                        awaiting_clarification=False
                    )
                    
                    if new_summary_point:
                        append_summary(new_summary_point)
                    
                    # Save as bot initiating the conversation (empty user query for greeting)
                    append_chat_history("", bot_answer)
                    
                    # Save the greeting as a question
                    if "?" in bot_answer:
                        save_asked_question(question_category, bot_answer)
                    
                    # Mark session as initialized
                    session_data["session_initialized"] = True
                    
                    return ChatResponse(
                        response=bot_answer,
                        session_initialized=True
                    )
                    
                except json.JSONDecodeError as e:
                    print(f"JSON Error in greeting: {e}")
                    fallback_greeting = "Hello! I'm Anusha from IQ-Techmax, and I'll be your interviewer today. Could you please introduce yourself?"
                    append_chat_history("", fallback_greeting)
                    session_data["session_initialized"] = True
                    return ChatResponse(response=fallback_greeting, session_initialized=True)
                except Exception as e:
                    print(f"Error in greeting: {e}")
                    append_chat_history("", response_text)
                    session_data["session_initialized"] = True
                    return ChatResponse(response=response_text, session_initialized=True)
            else:
                fallback_greeting = "Hello! I'm Anusha from IQ-Techmax, and I'll be your interviewer today. Could you please introduce yourself?"
                append_chat_history("", fallback_greeting)
                session_data["session_initialized"] = True
                return ChatResponse(response=fallback_greeting, session_initialized=True)
        
        else:
            # Normal conversation flow - process user's message
            response = generate_response(
                query=request.message,
                source="api_chat",
                name="Anusha",
                role="IQ-Techmax HR Interviewer",
                description="Professional HR interviewer conducting technical assessments.",
                resume_content=session_data["resume_content"],
                jd_content=session_data["jd_content"]
            )
            
            if not session_data["session_initialized"]:
                session_data["session_initialized"] = True
            
            return ChatResponse(
                response=response,
                session_initialized=session_data["session_initialized"]
            )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating response: {str(e)}")

@app.get("/session/status", response_model=SessionStatusResponse)
async def get_session_status():
    interview_state = load_interview_state()
    
    return SessionStatusResponse(
        jd_received=bool(session_data["jd_content"]),
        resume_received=bool(session_data["resume_content"]),
        session_ready=bool(session_data["jd_content"] and session_data["resume_content"]),
        session_initialized=session_data["session_initialized"],
        questions_asked=interview_state.get("question_count", 0),
        interview_phase=interview_state.get("current_phase", "not_started")
    )

@app.get("/interview/state", response_model=InterviewStateResponse)
async def get_interview_state():
    return InterviewStateResponse(state=load_interview_state())

@app.post("/session/reset", response_model=SessionResetResponse)
async def reset_session():
    session_data["jd_content"] = ""
    session_data["resume_content"] = ""
    session_data["session_initialized"] = False
    
    save_json_file(CHAT_HISTORY_FILE, [])
    save_json_file(SUMMARY_FILE, [])
    save_json_file(ASKED_QUESTIONS_FILE, [])
    save_json_file(INTERVIEW_STATE_FILE, [])
    
    return SessionResetResponse(message="Session reset successfully")

@app.get("/chat/history", response_model=ChatHistoryResponse)
async def get_chat_history():
    return ChatHistoryResponse(history=load_chat_history())

@app.get("/chat/summary", response_model=ChatSummaryResponse)
async def get_chat_summary():
    return ChatSummaryResponse(summary=load_summary())

@app.get("/debug/questions")
async def get_asked_questions():
    return {
        "asked_questions": load_asked_questions(),
        "questions_summary": get_asked_questions_summary(),
        "interview_state": load_interview_state()
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
    