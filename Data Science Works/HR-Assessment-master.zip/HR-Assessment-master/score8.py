import os
import json
import time
import requests
from dotenv import load_dotenv
from pinecone import Pinecone, ServerlessSpec
import pdfplumber
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any
import json 


# Load environment variables
load_dotenv()

PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
INDEX_NAME = "iq-bot-demo1"
CHAT_HISTORY_FILE = "score_chat_nhistory.txt"
SUMMARY_FILE = "score_chat_nsummary.txt"

# Initialize FastAPI
app = FastAPI(title="IQ-Techmax HR Evaluation API", version="1.0.0")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Pinecone client
pc = Pinecone(api_key=PINECONE_API_KEY)

def initialize_pinecone_index():
    if INDEX_NAME not in pc.list_indexes().names():
        pc.create_index(
            name=INDEX_NAME,
            dimension=768,
            metric="cosine",
            spec=ServerlessSpec(cloud="aws", region="us-east-1")
        )
    return pc.Index(INDEX_NAME)

index = initialize_pinecone_index()

# === PDF Parsing Functions ===

def parse_pdf_resume(pdf_path):
    with pdfplumber.open(pdf_path) as pdf:
        full_text = ''
        for page in pdf.pages:
            text = page.extract_text()
            if text:
                full_text += text + '\n'
    return full_text

# == JD Parshing Function === # 

def parse_pdf_jd(filepath):
    with pdfplumber.open(filepath) as pdf:
        text = ""
        for page in pdf.pages:
            text += page.extract_text()
    return text

# === File operations ===

def load_json_file(file_path):
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return []
    return []

def save_json_file(file_path, data):
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

# === Chat history management ===

def append_chat_history(user_query, bot_response):
    history = load_json_file(CHAT_HISTORY_FILE)
    current_index = history[-1]["index"] + 1 if history else 1
    history.append({
        "index": current_index,
        "user": user_query.strip(),
        "bot": bot_response.strip(),
        "timestamp": time.time()
    })
    save_json_file(CHAT_HISTORY_FILE, history)

# === Summary management ===

def append_summary(new_summary_point):
    summary = load_json_file(SUMMARY_FILE)
    current_index = summary[-1]["index"] + 1 if summary else 1
    summary.append({
        "index": current_index,
        "summary": new_summary_point.strip(),
        "timestamp": time.time()
    })
    save_json_file(SUMMARY_FILE, summary)

# === Embedding and context retrieval ===

def get_embedding(query):
    return [0.0] * 768  # Dummy embedding

def query_pinecone(query):
    vector = get_embedding(query)
    result = index.query(vector=vector, top_k=5, include_metadata=True)
    context = []
    if "matches" in result:
        for match in result["matches"]:
            metadata = match.get("metadata", {})
            if "text" in metadata:
                context.append(metadata["text"])
    return "\n".join(context)

# === Gemini API interaction ===

def get_gemini_response(prompt, retries=3, backoff=2):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={GOOGLE_API_KEY}"
    headers = {"Content-Type": "application/json"}
    data = {"contents": [{"parts": [{"text": prompt}]}]}

    for attempt in range(retries):
        try:
            response = requests.post(url, headers=headers, json=data)
            if response.status_code == 503:
                print(f"Gemini 503 error (service unavailable), attempt {attempt + 1} of {retries}. Retrying...")
                time.sleep(backoff * (attempt + 1))
                continue
            response.raise_for_status()
            result = response.json()
            return result['candidates'][0]['content']['parts'][0]['text']
        except requests.exceptions.RequestException as e:
            print(f"Gemini API Error: {e}")
            time.sleep(backoff * (attempt + 1))

    print("Gemini API failed after retries.")
    return None

# === Core Evaluation Function ===

def generate_evaluation():
    # Parse the fixed PDF files
    try:
        jd_content = parse_pdf_jd("job.pdf")
        resume_content = parse_pdf_resume("resumes/ResumeB.VINOTHRAJ.pdf")
        
        # Load formatted chat data
        formatted_chat = ""
        try:
            with open("formatted_chat.txt", "r", encoding="utf-8") as f:
                formatted_chat = f.read()
        except FileNotFoundError:
            formatted_chat = "No interview data found"
        
    except Exception as e:
        return {
            "error": f"Failed to load required files: {str(e)}",
            "message": "Please ensure job.pdf, resumes/ResumeB.VINOTHRAJ.pdf and formatted_chat.txt exist"
        }

    context = query_pinecone("candidate evaluation")
    
    system_prompt = f"""
    You are Anusha, a IQ-Techmax HR Evaluator built by IQ TechMax. You are an expert HR evaluator designed to assess candidate performance and provide detailed job eligibility scoring.

    **Your Task:** Evaluate the candidate's eligibility for the job position by analyzing:
    1. Job Description requirements
    2. Candidate's Resume/Background
    3. Interview Performance (Questions & Answers)

    **DATA PROVIDED:**

    Job Description:
    {jd_content}

    Candidate Resume:
    {resume_content}

    Interview Q&A Data:
    {formatted_chat}

    **EVALUATION CRITERIA:**

    1. **Technical Skills Match (10%)**: How well candidate's technical skills align with job requirements
    2. **Experience Relevance (15%)**: Relevance of past experience to the role
    3. **Interview Performance (60%)**: Quality of answers, problem-solving ability, communication
    4. **Cultural Fit & Soft Skills (15%)**: Leadership, teamwork, adaptability based on responses

    **SCORING INSTRUCTIONS:**
    - Analyze each criterion and assign a score out of 100
    - Calculate weighted average for overall eligibility percentage
    - Provide specific evidence from resume and interview responses
    - Compare candidate qualifications directly against job requirements

    **REQUIRED OUTPUT FORMAT (JSON):**
    {{
      "overall_eligibility_percentage": 75,
      "detailed_scores": {{
        "technical_skills_match": {{
          "score": 80,
          "evidence": "Specific examples from resume/interview",
          "gaps": "Areas where candidate falls short"
        }},
        "experience_relevance": {{
          "score": 70,
          "evidence": "Relevant experience examples",
          "gaps": "Missing experience areas"
        }},
        "interview_performance": {{
          "score": 75,
          "evidence": "Strong answers and examples",
          "gaps": "Weak responses or unclear explanations"
        }},
        "cultural_fit_soft_skills": {{
          "score": 80,
          "evidence": "Leadership/teamwork examples",
          "gaps": "Areas needing development"
        }}
      }},
      "key_strengths": [
        "List 3-4 major strengths with specific examples"
      ],
      "key_weaknesses": [
        "List 3-4 areas for improvement with examples"
      ],
      "hiring_recommendation": {{
        "decision": "STRONGLY RECOMMEND/RECOMMEND/MAYBE/NOT RECOMMEND",
        "confidence_level": 85,
        "reasoning": "Detailed explanation for the recommendation based on analysis"
      }},
      "detailed_assessment": "Comprehensive 2-3 paragraph evaluation covering all aspects of candidate's fit for the role, including specific examples from their responses and resume that support your scoring and recommendation."
    }}

    **DECISION CRITERIA:**
    - STRONGLY RECOMMEND: 80%+ eligibility, excellent fit
    - RECOMMEND: 70-79% eligibility, good fit with minor gaps
    - MAYBE: 60-69% eligibility, moderate fit with some concerns
    - NOT RECOMMEND: <60% eligibility, significant gaps or poor fit

    Focus on objective evaluation based on concrete evidence from the provided data. Be thorough and specific in your analysis.
    """
    
    response_text = get_gemini_response(system_prompt)

    if response_text:
        try:
            # Clean the response text and parse as JSON
            cleaned_response = response_text.replace("```json", "").replace("```", "").strip()
            response_json = json.loads(cleaned_response)
            
            # Create a summary point from the evaluation
            overall_score = response_json.get("overall_eligibility_percentage", "N/A")
            decision = response_json.get("hiring_recommendation", {}).get("decision", "N/A")
            new_summary_point = f"Candidate evaluation completed - Overall Score: {overall_score}%, Recommendation: {decision}"
            
            append_summary(new_summary_point)
            append_chat_history("Evaluate the candidate", json.dumps(response_json, indent=2))
            
            return response_json
            
        except json.JSONDecodeError as e:
            print(f"JSON Parsing Error: {e}")
            error_response = {
                "error": "Failed to parse evaluation response",
                "raw_response": response_text,
                "message": "The AI response could not be parsed as JSON"
            }
            append_chat_history("Evaluate the candidate", response_text)
            return error_response
        except Exception as e:
            print(f"General Parsing Error: {e}")
            error_response = {
                "error": f"Evaluation processing error: {str(e)}",
                "raw_response": response_text
            }
            append_chat_history("Evaluate the candidate", response_text)
            return error_response
    else:
        error_response = {
            "error": "No response from Gemini API",
            "message": "The AI service is currently unavailable. Please try again later."
        }
        append_chat_history("Evaluate the candidate", "No response from Gemini")
        return error_response

# === Pydantic Models ===

class EvaluationResponse(BaseModel):
    success: bool
    evaluation_result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    message: Optional[str] = None

# === API Endpoint ===

@app.post("/start-evaluation", response_model=EvaluationResponse)
async def start_evaluation():
    """
    Start the candidate evaluation process.
    This endpoint reads the fixed files and returns the evaluation result.
    """
    try:
        print("Starting candidate evaluation...")
        
        evaluation_result = generate_evaluation()
        
        if "error" in evaluation_result:
            return EvaluationResponse(
                success=False,
                error=evaluation_result.get("error"),
                message=evaluation_result.get("message", "Evaluation failed")
            )
        else:
            print("Evaluation completed successfully!")
            return EvaluationResponse(
                success=True,
                evaluation_result=evaluation_result,
                message="Candidate evaluation completed successfully"
            )
        
    except Exception as e:
        print(f"Evaluation endpoint error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error during evaluation: {str(e)}")

    
def convert_json_array_txt_to_conversation(input_path, output_path):
    with open(input_path, 'r', encoding='utf-8') as f:
        data = f.read().strip()

    try:
        chat_data = json.loads(data)
    except Exception as e:
        print(f"Failed to parse JSON. Error: {e}")
        return

    conversation_lines = []

    for entry in chat_data:
        user = entry.get("user", "").strip()
        bot = entry.get("bot", "").strip()

        if user:
            conversation_lines.append(f"Candidate: {user}")
        if bot:
            conversation_lines.append(f"Interviewer: {bot}")
        
        conversation_lines.append("")  # blank line for readability

    with open(output_path, 'w', encoding='utf-8') as out:
        out.write("\n".join(conversation_lines))

    print(f"Formatted conversation saved to: {output_path}")
#  Usage
convert_json_array_txt_to_conversation("chat_nhistory.txt", "formatted_chat.txt")
if __name__ == "__main__":
    convert_json_array_txt_to_conversation()
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

    