from dotenv import load_dotenv
import os
import google.generativeai as genai

# ----------------------------
# Environment & Model Setup
# ----------------------------
load_dotenv()

GOOGLE_API_KEY = os.environ.get("GOOGLE_API_KEY")
if not GOOGLE_API_KEY:
    raise RuntimeError("Missing GOOGLE_API_KEY in .env file")

genai.configure(api_key=GOOGLE_API_KEY)
model = genai.GenerativeModel("models/gemini-1.5-flash")


# ----------------------------
# Helper: AI Response Generator
# ----------------------------
def ai_say(step_description: str, mode: str) -> str:
    """Generate response for scripted flow steps."""
    prompt = f"""You are an AI {mode} Call Agent.
Step: {step_description}
Generate a short, professional, natural-sounding call script for this step.
Do not explain what you're doing—just speak as if you're the agent talking to the customer."""
    resp = model.generate_content(prompt)
    return (resp.text or "").strip()


def ai_chat(user_input: str, mode: str) -> str:
    """Handle free-form customer questions (Q&A mode)."""
    prompt = f"""You are an AI {mode} Call Agent.
Customer says: "{user_input}"
Your job:
- Understand the customer's intent.
- Answer naturally and professionally.
- If it's a service-related question, provide service details/offers.
- If it's a sales-related question, provide sales support.
- Don't force a full script. Just answer what the customer is asking."""
    resp = model.generate_content(prompt)
    return (resp.text or "").strip()


# ----------------------------
# Sales Agent
# ----------------------------
class SalesAgent:
    def __init__(self):
        self.mode = "Sales"
        self.flow = [
            ("Cold Calling & Lead Generation", self.cold_calling),
            ("Follow-Up & Lead Qualification", self.follow_up),
            ("Test Drive & Home Visit", self.test_drive),
            ("Quotation & Finance", self.quotation),
            ("Negotiation & Finalization", self.negotiation),
            ("Accessories & Insurance Upselling", self.upsell_accessories),
            ("Booking & Document Handling", self.booking),
            ("Pre-Delivery Inspection & Delivery", self.delivery),
            ("Post-Delivery Follow-Up", self.post_delivery),
        ]

    # Sales Steps
    def cold_calling(self): return ai_say("Cold Calling & Lead Generation: Introduce dealership, ask about preferences, schedule next call if interested.", self.mode)
    def follow_up(self): return ai_say("Follow-Up & Lead Qualification: Answer queries, suggest test drive/home visit, qualify interest.", self.mode)
    def test_drive(self): return ai_say("Test Drive & Home Visit: Confirm appointment before, call after to get feedback.", self.mode)
    def quotation(self): return ai_say("Quotation & Finance: Discuss pricing, offers, and finance options.", self.mode)
    def negotiation(self): return ai_say("Negotiation & Finalization: Handle negotiations, smooth communication.", self.mode)
    def upsell_accessories(self): return ai_say("Accessories & Insurance Upselling: Suggest accessories, insurance, warranties.", self.mode)
    def booking(self): return ai_say("Booking & Document Handling: Guide booking, explain digital documentation.", self.mode)
    def delivery(self): return ai_say("Pre-Delivery Inspection & Delivery: Confirm delivery date, schedule PDI, notify customer.", self.mode)
    def post_delivery(self): return ai_say("Post-Delivery Follow-Up: Check satisfaction, offer future assistance.", self.mode)

    def run(self):
        print("\n Sales Agent Flow Started...\n")
        for i, (title, func) in enumerate(self.flow, 1):
            print(f"\n➡️ Step {i}/{len(self.flow)}: {title}")
            print(f"Agent: {func()}")
            input("Press ENTER for next step...")


# ----------------------------
# Service Agent
# ----------------------------
class ServiceAgent:
    def __init__(self):
        self.mode = "Service"
        self.flow = [
            ("Service Reminder", self.reminder),
            ("Appointment Confirmation", self.confirmation),
            ("Service Status Update", self.status_update),
            ("Upsell Add-ons", self.upsell_addons),
            ("Payment & Invoicing", self.payment),
            ("Service Feedback", self.feedback),
            ("Complaint Handling", self.complaint),
            ("Customer Loyalty", self.loyalty),
        ]

    # Service Steps
    def reminder(self): return ai_say("Service Reminder: Call about upcoming service, offer to schedule.", self.mode)
    def confirmation(self): return ai_say("Service Appointment Confirmation: Confirm one day before and same day.", self.mode)
    def status_update(self): return ai_say("Service Status Update: Give updates on service progress & extra work.", self.mode)
    def upsell_addons(self): return ai_say("Upsell Service Add-ons: Suggest additional services like engine cleaning.", self.mode)
    def payment(self): return ai_say("Payment & Invoicing: Notify invoice readiness, explain payment methods.", self.mode)
    def feedback(self): return ai_say("Service Feedback: Next-day, 3rd-day, and 10th-day follow-ups.", self.mode)
    def complaint(self): return ai_say("Complaint Feedback: If negative feedback, call to resolve complaint.", self.mode)
    def loyalty(self): return ai_say("Customer Satisfaction & Loyalty: Offer discounts, loyalty programs, referrals.", self.mode)

    def run(self):
        print("\n🔧 Service Agent Flow Started...\n")
        for i, (title, func) in enumerate(self.flow, 1):
            print(f"\n➡️ Step {i}/{len(self.flow)}: {title}")
            print(f"Agent: {func()}")
            input("Press ENTER for next step...")


# ----------------------------
# Free Q&A Mode
# ----------------------------
def free_chat(mode="Service"):
    print(f"\n Free Q&A Mode ({mode}) — Ask me anything. Type 'exit' to quit.\n")
    while True:
        customer = input("👤 Customer: ").strip()
        if customer.lower() in ("exit", "quit"):
            print("👋 Ending free chat.")
            break
        reply = ai_chat(customer, mode)
        print(f"Agent: {reply}\n")


# ----------------------------
# CLI Entrypoint
# ----------------------------
def main():
    print("AI Sales/Service Agent — Gemini Powered\n")
    print("Options:")
    print("  sales   → Run Sales Flow (step-by-step)")
    print("  service → Run Service Flow (step-by-step)")
    print("  chat    → Free Q&A Mode (ask anything)")
    print("  exit    → Quit\n")

    while True:
        choice = input("> ").strip().lower()
        if choice == "exit":
            print("👋 Goodbye!")
            break
        elif choice == "sales":
            SalesAgent().run()
        elif choice == "service":
            ServiceAgent().run()
        elif choice == "chat":
            mode = input("Choose mode (sales/service): ").strip().capitalize()
            if mode not in ("Sales", "Service"):
                mode = "Service"
            free_chat(mode)
        else:
            print("❌ Invalid choice. Try again.")


if __name__ == "__main__":
    main()
