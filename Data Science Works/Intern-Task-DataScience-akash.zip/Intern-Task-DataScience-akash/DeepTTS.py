import pyttsx3
import os
from dotenv import load_dotenv
import time
import sys

# ✅ Load environment variables from a specific .env file path (assuming it's relevant for other settings)
load_dotenv(dotenv_path=r"C:\Users\Akash\OneDrive\Desktop\Python_workspace\env\DeepgramAPI\.env\.env")

# For debugging: Print API Key to confirm it's loaded (opti2    `onal, then remove)
# print("Loaded API Key:", os.getenv("DEEPGRAM_API_KEY"))

def main():
    try:
        # Fetch the API key if you still need it for any other reason
        api_key = os.getenv("DEEPGRAM_API_KEY")
        if not api_key:
            print("Error: DEEPGRAM_API_KEY is not set in .env file.")
            return
        
        # Initialize pyttsx3 for TTS
        engine = pyttsx3.init()
        voices = engine.getProperty('voices')
        
        # Set the voice (use 0 for male, 1 for female, or you can specify based on index)
        engine.setProperty('voice', voices[1].id)  # Change this based on your preference
        
        # Set rate of speech
        rate = engine.getProperty('rate')
        engine.setProperty('rate', 150)  # Speed up or slow down as needed
        
        # Set volume level (0.0 to 1.0)
        volume = engine.getProperty('volume')
        engine.setProperty('volume', 1.0)

        print("Text-to-Speech Engine Initialized...\n")

        print("Type 'exit' to stop the program.\n")
        
        while True:
            # Continuously take input from the user
            text_to_speak = input("Type text to speak: ")

            if text_to_speak.lower() == "exit":
                print("Exiting program.")
                break

            # Optionally clear console to refresh each time
            # sys.stdout.write("\033[H\033[J")  # This is for clearing terminal on some systems
            # sys.stdout.flush()

            print(f"Speaking: {text_to_speak}\n")
            
            # Speak the typed text
            engine.say(text_to_speak)
            engine.runAndWait()

            print("Finished Speaking...\n")
            
            # Add a short delay before the next input
            time.sleep(1)

    except Exception as e:
        print(f"Error: {e}")
        return

if __name__ == "__main__":
    main()
