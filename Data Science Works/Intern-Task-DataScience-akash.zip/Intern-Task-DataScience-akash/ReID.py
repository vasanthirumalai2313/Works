import cv2
import time
import numpy as np
from collections import defaultdict
from ultralytics import YOLO
from deep_sort_realtime.deepsort_tracker import DeepSort

# ========== Dummy ReID Model (built-in) ==========
class ReIDModel:
    def __init__(self, model_path=None):
        print("Dummy ReID model initialized")

    def extract_features(self, image):
        # Simulated 128-dimensional feature vector
        return np.random.rand(128)

# ========== Cosine Similarity ==========
def cosine_similarity(vec1, vec2):
    dot = np.dot(vec1, vec2)
    norm1 = np.linalg.norm(vec1)
    norm2 = np.linalg.norm(vec2)
    return dot / (norm1 * norm2 + 1e-10)

# ========== Components ==========
id_cache = {}
MAX_DISAPPEAR_TIME = 30  # seconds

yolo = YOLO("yolov8n.pt")  # Load YOLOv8 nano model
tracker = DeepSort(max_age=30)
reid = ReIDModel()

def update_cache(person_id, reid_feature):
    id_cache[person_id] = {
        'feature': reid_feature,
        'timestamp': time.time()
    }

def find_matching_id(reid_feature):
    current_time = time.time()
    for cached_id, data in id_cache.items():
        if current_time - data['timestamp'] <= MAX_DISAPPEAR_TIME:
            similarity = cosine_similarity(reid_feature, data['feature'])
            if similarity > 0.8:
                return cached_id
    return None

# ========== Main Loop ==========
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # YOLO detection
    results = yolo(frame)[0]
    detections = []
    for r in results.boxes.data.tolist():
        x1, y1, x2, y2, score, class_id = r
        if int(class_id) == 0:  # class 0 is 'person'
            detections.append(([x1, y1, x2 - x1, y2 - y1], score, 'person'))

    # Track
    tracks = tracker.update_tracks(detections, frame=frame)
    for track in tracks:
        if not track.is_confirmed():
            continue
        track_id = track.track_id
        l, t, w, h = track.to_ltrb()
        bbox = [int(l), int(t), int(l + w), int(t + h)]

        person_crop = frame[bbox[1]:bbox[3], bbox[0]:bbox[2]]
        if person_crop.size == 0:
            continue

        reid_feature = reid.extract_features(person_crop)

        if track_id not in id_cache:
            matched_id = find_matching_id(reid_feature)
            if matched_id:
                print(f"Reassigned ID {matched_id}")
                track_id = matched_id  # Use matched ID
        update_cache(track_id, reid_feature)

        cv2.rectangle(frame, (bbox[0], bbox[1]), (bbox[2], bbox[3]), (255, 0, 0), 2)
        cv2.putText(frame, f"ID: {track_id}", (bbox[0], bbox[1]-10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

    cv2.imshow("Customer ReID Tracker", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
