import os
import threading
import urllib.request
import pyaudio
from dotenv import load_dotenv
from deepgram import DeepgramClient, LiveTranscriptionEvents, LiveOptions

# Load .env
load_dotenv(dotenv_path=r"C:\Users\Akash\OneDrive\Desktop\Python_workspace\env\DeepgramAPI\.env\.env")
DEEPGRAM_API_KEY = os.getenv("DEEPGRAM_API_KEY")

# Live stream URL
AUDIO_STREAM_URL = "http://stream.live.vc.bbcmedia.co.uk/bbc_world_service"

# Audio format for PyAudio
CHUNK = 1024
FORMAT = pyaudio.paInt16
CHANNELS = 2
RATE = 44100

def stream_audio_to_deepgram_and_play():
    # Initialize Deepgram client
    deepgram = DeepgramClient(DEEPGRAM_API_KEY)
 
    # Deepgram options
    options = LiveOptions(
        model="nova-2",
        language="en-US",
        punctuate=True, 

        interim_results=False
    )

    # Create Deepgram connection
    dg_connection = deepgram.listen.live.v("1", options)

    # Transcript handler
    def on_transcript(self, transcript, **kwargs):
        text = transcript.channel.alternatives[0].transcript
        if text:
            print("📝 Transcript:", text)

    dg_connection.on(LiveTranscriptionEvents.Transcript, on_transcript)

    # Start connection
    if not dg_connection.start():
        print("❌ Failed to connect to Deepgram")
        return

    # Setup audio player
    p = pyaudio.PyAudio()
    stream_player = p.open(format=FORMAT, channels=CHANNELS, rate=RATE, output=True)

    # Read audio from online stream
    with urllib.request.urlopen(AUDIO_STREAM_URL) as stream:
        print("🎧 Listening and transcribing...\nPress Ctrl+C to stop.\n")
        try:
            while True:
                audio_chunk = stream.read(CHUNK)
                if not audio_chunk:
                    break

                # Send to Deepgram
                dg_connection.send(audio_chunk)

                # Play audio locally
                stream_player.write(audio_chunk)

        except KeyboardInterrupt:
            print("\n🛑 Stopping transcription.")
        finally:
            dg_connection.finish()
            stream_player.stop_stream()
            stream_player.close()
            p.terminate()

if __name__ == "__main__":
    stream_audio_to_deepgram_and_play()
