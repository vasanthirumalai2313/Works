import os
import json
import requests
from pinecone import Pinecone, ServerlessSpec

# API Keys
PINECONE_API_KEY = "pcsk_5zopuj_2KQTvFYBxwsahjo46HDCFy6ADfBK3PuFg3PjXJeHLfKe2Dw5bMrUc1ypfdhKirH"
GOOGLE_API_KEY = "AIzaSyCAQoIw6PfyKFCH7Yc4q6u6BL_5-bgbs30"
INDEX_NAME = "iq-bot-demo1"

# Initialize Pinecone
pc = Pinecone(api_key=PINECONE_API_KEY)
index = pc.Index(INDEX_NAME) if INDEX_NAME in pc.list_indexes().names() else pc.create_index(
    name=INDEX_NAME,
    dimension=768,
    metric="cosine",
    spec=ServerlessSpec(cloud="aws", region="us-east-1")
)

# In-memory user sessions
USER_SESSIONS = {}

# === Utility Functions ===

def get_history_file(user_id):
    return f"{user_id}_chat_history.json"

def get_summary_file(user_id):
    return f"{user_id}_chat_summary.json"

def load_json_file(file_path):
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return []
    return []

def save_json_file(file_path, data):
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def estimate_token_count(text):
    words = text.split()
    return int(len(words) * 0.75)

def get_embedding(query):
    return [0.0] * 768  # Dummy placeholder

def query_pinecone(query):
    vector = get_embedding(query)
    result = index.query(vector=vector, top_k=5, include_metadata=True)
    context = []
    if "matches" in result:
        for match in result["matches"]:
            metadata = match.get("metadata", {})
            if "text" in metadata:
                context.append(metadata["text"])
    return "\n".join(context)

def get_gemini_response(prompt):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={GOOGLE_API_KEY}"
    headers = {"Content-Type": "application/json"}
    data = {"contents": [{"parts": [{"text": prompt}]}]}
    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        result = response.json()
        return result['candidates'][0]['content']['parts'][0]['text']
    except Exception as e:
        print(f"[Gemini Error] {e}")
        return None

# === Session Initialization ===

def initialize_user_session(user_id, name, role, description):
    summary = load_json_file(get_summary_file(user_id))
    chat_history = load_json_file(get_history_file(user_id))

    summary_text = "\n".join([f"{item['index']}. {item['summary']}" for item in summary]) if summary else "None yet"

    system_prompt = f"""
You are {name}, a {role} built by IQ TechMax. You are designed to respond to user questions with helpful and accurate answers strictly based on the provided context. Your character: {description}.

Instructions:
1. If the query relates to previous context, link to the summary and build on it.
2. If the user references a numbered summary point, respond with details.
3. First interaction: greet warmly and introduce yourself.
4. Always return JSON with:
   - "response": the answer
   - "updatedSummary": a short summary of what the user asked and what was answered.
5. Ask for clarification if needed.
6. If no context fits, say: "I don’t have relevant information based on the current context."
7. Be conversational and natural, especially for voice_chat.
"""

    USER_SESSIONS[user_id] = {
        "system_prompt": system_prompt,
        "summary": summary_text,
        "history": chat_history,
        "initialized": False
    }

# === Main Chat Logic ===

def generate_response(user_id, query, source, name, role, description):
    if user_id not in USER_SESSIONS:
        initialize_user_session(user_id, name, role, description)

    session = USER_SESSIONS[user_id]
    chat_history = session["history"]
    context = query_pinecone(query)

    # First-time full prompt vs minimal
    if not session["initialized"]:
        full_prompt = f"""{session['system_prompt']}

Summary:
{session['summary']}

Context:
{context}

Chat History:
{'\n'.join([f"User: {item['user']}\nBot: {item['bot']}" for item in chat_history[-5:]])}

New Query:
{query}
"""
        session["initialized"] = True
    else:
        full_prompt = f"""
User asked: {query}

Context:
{context}

(Respond strictly based on context. Return JSON with 'response' and 'updatedSummary'.)
"""

    input_tokens = estimate_token_count(full_prompt)
    response_text = get_gemini_response(full_prompt)

    if response_text:
        output_tokens = estimate_token_count(response_text)
        total_tokens = input_tokens + output_tokens

        print(f"\n[Token Usage]")
        print(f"Input Tokens: {input_tokens}")
        print(f"Output Tokens: {output_tokens}")
        print(f"Total Tokens: {total_tokens}\n")

        try:
            cleaned = response_text.replace("```json", "").replace("```", "").strip()
            response_json = json.loads(cleaned)
            bot_reply = response_json.get("response", "").strip()
            updated_summary = response_json.get("updatedSummary", "").strip()

            chat_history.append({"user": query, "bot": bot_reply})
            save_json_file(get_history_file(user_id), chat_history)

            summary_data = load_json_file(get_summary_file(user_id))
            summary_data.append({"index": len(summary_data) + 1, "summary": updated_summary})
            save_json_file(get_summary_file(user_id), summary_data)

# === Run ===
if __name__ == "__main__":
    start_chat()