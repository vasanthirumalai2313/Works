import os
import json
import requests
from pinecone import Pinecone, ServerlessSpec
from tiktoken import encoding_for_model
from dotenv import load_dotenv

# === Load environment variables ===
load_dotenv()

# === Secure API key handling ===
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

INDEX_NAME = "iq-bot-demo"
CHAT_HISTORY_FILE = "chat_nhistory.txt"
SUMMARY_FILE = "chat_nsummary.txt"

# === Initialize Pinecone client and index ===
pc = Pinecone(api_key=PINECONE_API_KEY)

def initialize_pinecone_index():
    if INDEX_NAME not in [i.name for i in pc.list_indexes()]:
        pc.create_index(
            name=INDEX_NAME,
            dimension=768,
            metric="cosine",
            spec=ServerlessSpec(cloud="aws", region="us-east-1")
        )
    return pc.Index(INDEX_NAME)

index = initialize_pinecone_index()

# === Utility: Token Estimation ===
def estimate_token_count(text):
    return int(len(text.split()) * 0.75)

def count_tokens(text, model="gpt-3.5-turbo"):
    enc = encoding_for_model(model)
    return len(enc.encode(text))

# === File Operations ===
def load_json_file(file_path):
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return []
    return []

def save_json_file(file_path, data):
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

# === Chat and Summary Management ===
def load_chat_history():
    return load_json_file(CHAT_HISTORY_FILE)

def append_chat_history(user_query, bot_response):
    history = load_chat_history()
    current_index = history[-1]["index"] + 1 if history else 1
    history.append({
        "index": current_index,
        "user": user_query.strip(),
        "bot": bot_response.strip()
    })
    save_json_file(CHAT_HISTORY_FILE, history)

def load_summary():
    return load_json_file(SUMMARY_FILE)

def append_summary(new_summary_point):
    summary = load_summary()
    current_index = summary[-1]["index"] + 1 if summary else 1
    summary.append({
        "index": current_index,
        "summary": new_summary_point.strip()
    })
    save_json_file(SUMMARY_FILE, summary)

# === Embedding and Retrieval ===
def get_embedding(query):
    # Replace with actual embedding generation logic (e.g., from HuggingFace or OpenAI)
    return [0.0] * 768

def query_pinecone_compressed(query, max_words=100):
    vector = get_embedding(query)
    result = index.query(vector=vector, top_k=5, include_metadata=True)
    context = []
    if hasattr(result, 'matches'):
        for match in result.matches:
            text = match.metadata.get("text", "")
            trimmed = " ".join(text.split()[:max_words])
            context.append(trimmed)
    return "\n".join(context)

def get_recent_summary(limit=5):
    summary = load_summary()
    return "\n".join([f"{item['index']}. {item['summary']}" for item in summary[-limit:]])

# === Gemini API Call ===
def get_gemini_response(prompt):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={GOOGLE_API_KEY}"
    headers = {"Content-Type": "application/json"}
    data = {"contents": [{"parts": [{"text": prompt}]}]}
    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        result = response.json()
        return result['candidates'][0]['content']['parts'][0]['text']
    except Exception as e:
        print(f"Gemini API Error: {e}")
        return None

# === Prompt Template ===
SYSTEM_PROMPT_TEMPLATE = """
You are {name}, a {role} built by IQ TechMax. You are designed to respond to user questions with helpful and accurate answers strictly based on the provided context. Your character: {description}.

Context:
{context}

Recent Summary:
{summary}

User Query:
{query}

Query source: {source}
Current Summary:
{current_summary}



Instructions:
    1. If the current query is related to a previous conversation (not detailed but referencing prior chat context):
       - Retrieve the relevant summary from the summary list.
       - Find the corresponding detailed history from the chat history list.
       - Provide an answer that links back to this context and build upon it.
       - If the query references a specific numbered summary point (e.g., "Tell me more about point 3"), return detailed context from the corresponding history entry.

    2. If the query is the first in the session (summary is "None yet"), introduce yourself in a friendly tone (e.g., "Hi, I'm {name}, your {role}. How can I assist you today?") and answer based on available context.

    3. Return a valid JSON object with two keys:
       - "response": Provide a concise, accurate answer based on the query and related context.
       - "updatedSummary": A brief update of the conversation in the format "The user asked about X and was informed Y."

    4. If the query does not provide clear direction or context:
       - Ask for clarification.

    5. If the context provided doesn't answer the query:
       - Respond: "I don't have relevant information on that topic based on the current context."

    6. Keep responses in a conversational and natural tone, especially for 'voice_chat' queries.
    """

# === Build Prompt ===
def build_optimized_prompt(query, name, role, description, source="text_chat", token_budget=3000, model="gpt-3.5-turbo"):
    context = query_pinecone_compressed(query)
    summary = get_recent_summary()
    current_summary = summary if summary else "None yet"

    prompt = SYSTEM_PROMPT_TEMPLATE.format(
        name=name,
        role=role,
        description=description,
        context=context,
        summary=summary,
        query=query,
        source=source,
        current_summary=current_summary
    )

    if count_tokens(prompt, model=model) > token_budget:
        context = "\n".join(context.split("\n")[:3])
        summary = "\n".join(summary.split("\n")[:3])
        prompt = SYSTEM_PROMPT_TEMPLATE.format(
            name=name,
            role=role,
            description=description,
            context=context,
            summary=summary,
            query=query,
            source=source,
            current_summary=current_summary
        )
    return prompt

# === Generate AI Response ===
def generate_response(query, source, name, role, description):
    prompt = build_optimized_prompt(query, name, role, description, source)
    input_tokens = estimate_token_count(prompt)
    response_text = get_gemini_response(prompt)

    if response_text:
        output_tokens = estimate_token_count(response_text)
        total_tokens = input_tokens + output_tokens
        print(f"\n[Token Usage]\nInput Tokens: {input_tokens}\nOutput Tokens: {output_tokens}\nTotal: {total_tokens}\n")

        try:
            cleaned = response_text.replace("```json", "").replace("```", "").strip()
            response_json = json.loads(cleaned)
            bot_answer = response_json.get("response", "").strip()
            updated_summary = response_json.get("updatedSummary", "").strip()
            if bot_answer:
                append_summary(updated_summary)
                append_chat_history(query, bot_answer)
                return bot_answer
        except Exception as e:
            print(f"JSON Parsing Error: {e}")
            append_chat_history(query, response_text)
            return response_text
    else:
        append_chat_history(query, "No response")
        return "Sorry, no response from Gemini."

# === CLI ===
def start_chat():
    print("Start chatting with KTM. Type 'exit' to stop.\n")
    while True:
        user_input = input("User: ")
        if user_input.lower() in ("exit", "quit"):
            print("Chat ended.")
            break
        response = generate_response(
            query=user_input,
            source="text_chat",
            name="KTM",
            role="AI Assistant",
            description="A helpful and strict assistant with access only to provided context."
        )
        print("Bot:", response)

if __name__ == "__main__":
    start_chat()
