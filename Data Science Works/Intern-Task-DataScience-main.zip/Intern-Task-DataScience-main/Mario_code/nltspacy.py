import os
import json
import requests
import nltk
import spacy
from nltk.corpus import stopwords
from pinecone import Pinecone, ServerlessSpec

# === NLP Setup ===
nltk.download('punkt')
nltk.download('stopwords')
nlp = spacy.load("en_core_web_sm")
stop_words = set(stopwords.words("english"))

# === Load environment variables ===
PINECONE_API_KEY = "pcsk_5zopuj_2KQTvFYBxwsahjo46HDCFy6ADfBK3PuFg3PjXJeHLfKe2Dw5bMrUc1ypfdhKirH"
GOOGLE_API_KEY = "AIzaSyCAQoIw6PfyKFCH7Yc4q6u6BL_5-bgbs30"
INDEX_NAME = "iq-bot-demo1"
CHAT_HISTORY_FILE = "chat_nhistory.txt"
SUMMARY_FILE = "chat_nsummary.txt"

# === Initialize Pinecone ===
pc = Pinecone(api_key=PINECONE_API_KEY)

def initialize_pinecone_index():
    if INDEX_NAME not in pc.list_indexes().names():
        pc.create_index(
            name=INDEX_NAME,
            dimension=768,
            metric="cosine",
            spec=ServerlessSpec(cloud="aws", region="us-east-1")
        )
    return pc.Index(INDEX_NAME)

index = initialize_pinecone_index()

# === File operations ===
def load_json_file(file_path):
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return []
    return []

def save_json_file(file_path, data):
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

# === Chat/Summary operations ===
def load_chat_history():
    return load_json_file(CHAT_HISTORY_FILE)

def append_chat_history(user_query, bot_response):
    history = load_chat_history()
    current_index = history[-1]["index"] + 1 if history else 1
    history.append({"index": current_index, "user": user_query.strip(), "bot": bot_response.strip()})
    save_json_file(CHAT_HISTORY_FILE, history)

def load_summary():
    return load_json_file(SUMMARY_FILE)

def append_summary(new_summary_point):
    summary = load_summary()
    current_index = summary[-1]["index"] + 1 if summary else 1
    summary.append({"index": current_index, "summary": new_summary_point.strip()})
    save_json_file(SUMMARY_FILE, summary)

# === Embedding and context retrieval ===
def get_embedding(query):
    return [0.0] * 768  # Dummy embedding

def query_pinecone(query):
    vector = get_embedding(query)
    result = index.query(vector=vector, top_k=5, include_metadata=True)
    context = []
    if "matches" in result:
        for match in result["matches"]:
            metadata = match.get("metadata", {})
            if "text" in metadata:
                context.append(metadata["text"])
    return context

# === NLP-based relevance filtering ===
def extract_keywords(text):
    doc = nlp(text.lower())
    return [token.lemma_ for token in doc if token.is_alpha and token.text not in stop_words]

def filter_relevant_items(query, items, key):
    query_keywords = set(extract_keywords(query))
    scored_items = []
    for item in items:
        content = item.get(key, "")
        item_keywords = set(extract_keywords(content))
        score = len(query_keywords & item_keywords)
        scored_items.append((score, item))
    scored_items.sort(reverse=True, key=lambda x: x[0])
    return [item for score, item in scored_items[:3] if score > 0]

# === Gemini API interaction ===
def get_gemini_response(prompt):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={GOOGLE_API_KEY}"
    headers = {"Content-Type": "application/json"}
    data = {"contents": [{"parts": [{"text": prompt}]}]}
    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        result = response.json()
        return result['candidates'][0]['content']['parts'][0]['text']
    except Exception as e:
        print(f"Gemini Error: {e}")
        return None

# === AI Response Generation ===
def generate_response(query, source, name, role, description):
    summary_data = load_summary()
    chat_history_data = load_chat_history()
    context_chunks = query_pinecone(query)

    relevant_summary = filter_relevant_items(query, summary_data, "summary")
    relevant_history = filter_relevant_items(query, chat_history_data, "user")
    relevant_context = filter_relevant_items(query, [{"text": c} for c in context_chunks], "text")

    current_summary = "\n".join([f"{item['index']}. {item['summary']}" for item in relevant_summary])
    current_history = "\n".join([f"{item['index']}. User: {item['user']} | Bot: {item['bot']}" for item in relevant_history])
    context = "\n".join([item["text"] for item in relevant_context])

    system_prompt = f"""
    You are {name}, a {role} built by IQ TechMax. You are designed to respond to user questions with helpful and accurate answers strictly based on the provided context. Your character: {description}.

    User query: {query}
    Query source: {source}
    Current Summary:
    {current_summary if current_summary else "None yet"}

    Context:
    {context}

    Instructions:
    1. If the current query is related to a previous conversation (not detailed but referencing prior chat context):
       - Retrieve the relevant summary from the summary list.
       - Find the corresponding detailed history from the chat history list.
       - Provide an answer that links back to this context and build upon it.
       - If the query references a specific numbered summary point (e.g., "Tell me more about point 3"), return detailed context from the corresponding history entry.

    2. If the query is the first in the session (summary is "None yet"), introduce yourself in a friendly tone and answer based on available context.

    3. Return a valid JSON object with two keys:
       - "response": Provide a concise, accurate answer based on the query and related context.
       - "updatedSummary": A brief update of the conversation in the format "The user asked about X and was informed Y."

    4. If the query does not provide clear direction or context:
       - Ask for clarification.

    5. If the context provided doesn't answer the query:
       - Respond: "I don't have relevant information on that topic based on the current context."

    6. Keep responses in a conversational and natural tone, especially for 'voice_chat' queries.
    """

    response_text = get_gemini_response(system_prompt)

    if response_text:
        try:
            cleaned_response = response_text.replace("```json", "").replace("```", "").strip()
            response_json = json.loads(cleaned_response)
            bot_answer = response_json.get("response", "").strip()
            new_summary_point = response_json.get("updatedSummary", "").strip()
            append_summary(new_summary_point)
            append_chat_history(query, bot_answer)
            return bot_answer
        except Exception as e:
            print(f"Parsing Error: {e}")
            append_chat_history(query, response_text)
            return response_text
    else:
        append_chat_history(query, "No response")
        return "Sorry, no response from Gemini."

# === CLI Interface ===
def start_chat():
    print("Start chatting with KTM. Type 'exit' to stop.\n")
    while True:
        user_input = input("User: ")
        if user_input.lower() in ["exit", "quit"]:
            print("Chat ended.")
            break
        response = generate_response(
            query=user_input,
            source="text_chat",
            name="ktm",
            role="AI Assistant",
            description="A helpful and strict assistant with access only to provided context."
        )
        print("Bot:", response)

# === Run Chat ===
if __name__ == "__main__":
    start_chat()
