import os
import json
import requests
from pinecone import Pinecone, ServerlessSpec
import math 

PINECONE_API_KEY = "pcsk_5zopuj_2KQTvFYBxwsahjo46HDCFy6ADfBK3PuFg3PjXJeHLfKe2Dw5bMrUc1ypfdhKirH"
GOOGLE_API_KEY = "AIzaSyCAQoIw6PfyKFCH7Yc4q6u6BL_5-bgbs30"
INDEX_NAME = "iq-bot-demo1"

# Initialize Pinecone
pc = Pinecone(api_key=PINECONE_API_KEY)

def initialize_pinecone_index():
    if INDEX_NAME not in pc.list_indexes().names():
        pc.create_index(
            name=INDEX_NAME,
            dimension=768,
            metric="cosine",
            spec=ServerlessSpec(cloud="aws", region="us-east-1")
        )
    return pc.Index(INDEX_NAME)

index = initialize_pinecone_index()

def estimate_token_count(text):
    words = text.split()
    return int(len(words)*0.75)

# === File-based I/O ===

def get_summary_file(user_id): return f"{user_id}_summary.json"
def get_history_file(user_id): return f"{user_id}_history.json"

def load_json_file(file_path):
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            try: return json.load(f)
            except json.JSONDecodeError: return []
    return []

def save_json_file(file_path, data):
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

# === Pinecone Embedding and Retrieval ===

def get_embedding(query):
    return [0.0] * 768  # Replace with actual model later

def query_pinecone(query):
    vector = get_embedding(query)
    result = index.query(vector=vector, top_k=5, include_metadata=True)
    return "\n".join([match.get("metadata", {}).get("text", "") for match in result.get("matches", [])])

# === Gemini API ===

def get_gemini_response(prompt):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={GOOGLE_API_KEY}"
    headers = {"Content-Type": "application/json"}
    data = {"contents": [{"parts": [{"text": prompt}]}]}
    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        result = response.json()
        return result['candidates'][0]['content']['parts'][0]['text']
    except Exception as e:
        print(f"Gemini Error: {e}")
        return None

# === Session Store ===

USER_SESSIONS = {}

def initialize_user_session(user_id, name, role, description):
    summary_data = load_json_file(get_summary_file(user_id))
    summary_text = "\n".join([f"{item['index']}. {item['summary']}" for item in summary_data])
    system_prompt = f"""
You are {name}, a {role} built by IQ TechMax. You are designed to respond to user questions strictly based on the provided context.

Your character: {description}

Instructions:
- Link to summaries and chat history when referenced
- Return JSON with:
  - "response": main reply
  - "updatedSummary": brief summary update
- If unsure, ask for clarification.
"""
    USER_SESSIONS[user_id] = {
        "system_prompt": system_prompt.strip(),
        "summary": summary_text.strip() if summary_text else "None yet",
        "history": load_json_file(get_history_file(user_id))
    }

# === Response Generation ===

def generate_response(user_id, query, source, name, role, description):
    if user_id not in USER_SESSIONS:
        initialize_user_session(user_id, name, role, description)

    session = USER_SESSIONS[user_id]
    chat_history = session["history"]
    context = query_pinecone(query)

    history_snippet = "\n".join([
        f"User: {entry['user']}\nBot: {entry['bot']}"
        for entry in chat_history[-5:]
    ])

    full_prompt = f"""{session['system_prompt']}

Summary:
{session['summary']}

Context:
{context}

Recent Conversation:
{history_snippet}

New Query:
{query}
"""

    input_tokens = estimate_token_count(full_prompt)

    response_text = get_gemini_response(full_prompt)

    if response_text:
        output_tokens = estimate_token_count(response_text)
        total_tokens = input_tokens + output_tokens

        print(f"\n[Token Usage]")
        print(f"Input Tokens: {input_tokens}")
        print(f"Output Tokens: {output_tokens}")
        print(f"Total Tokens: {total_tokens}\n")

        try:
            cleaned = response_text.replace("```json", "").replace("```", "").strip()
            response_json = json.loads(cleaned)
            bot_reply = response_json.get("response", "").strip()
            updated_summary = response_json.get("updatedSummary", "").strip()

            chat_history.append({"user": query, "bot": bot_reply})
            save_json_file(get_history_file(user_id), chat_history)

            summary_data = load_json_file(get_summary_file(user_id))
            summary_data.append({"index": len(summary_data) + 1, "summary": updated_summary})
            save_json_file(get_summary_file(user_id), summary_data)

            # Update session in memory
            session["summary"] = "\n".join([f"{i['index']}. {i['summary']}" for i in summary_data])
            session["history"] = chat_history

            return bot_reply
        except Exception as e:
            print(f"Parsing error: {e}")
            chat_history.append({"user": query, "bot": response_text})
            save_json_file(get_history_file(user_id), chat_history)
            return response_text
    else:
        return "Sorry, no response from Gemini."

# === CLI Interface ===

def start_chat():
    print("Chat with KTM. Type 'exit' to quit.")
    user_id = input("Enter your user ID: ").strip()

    while True:
        user_input = input("You: ")
        if user_input.lower() in ["exit", "quit"]:
            print("Goodbye!")
            break

        response = generate_response(
            user_id=user_id,
            query=user_input,
            source="voice_chat",
            name="ktm",
            role="AI Assistant",
            description="A helpful and strict assistant with access only to provided context."
        )
        print("KTM:", response)

# === Run it ===

if __name__ == "__main__":
    start_chat()
