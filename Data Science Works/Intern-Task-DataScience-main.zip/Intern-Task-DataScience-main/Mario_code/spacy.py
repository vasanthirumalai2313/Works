import os
import json
import requests
import spacy
from dotenv import load_dotenv
from pinecone import Pinecone, ServerlessSpec

# === Setup ===
load_dotenv()
nlp = spacy.load("en_core_web_sm")

PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
INDEX_NAME = "iq-bot-demo"
CHAT_HISTORY_FILE = "chat_nhistory.txt"
SUMMARY_FILE = "chat_nsummary.txt"

# === Pinecone Init ===
pc = Pinecone(api_key=PINECONE_API_KEY)

def initialize_pinecone_index():
    if INDEX_NAME not in pc.list_indexes().names():
        pc.create_index(
            name=INDEX_NAME,
            dimension=768,
            metric="cosine",
            spec=ServerlessSpec(cloud="aws", region="us-east-1")
        )
    return pc.Index(INDEX_NAME)

index = initialize_pinecone_index()

# === Token Estimate ===
def estimate_token_count(text):
    return int(len(text.split()) * 0.75)

# === Files ===
def load_json_file(path):
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return []
    return []

def save_json_file(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

# === History/Summary Management ===
def load_chat_history():
    return load_json_file(CHAT_HISTORY_FILE)
nd 
def append_chat_history(user_query, bot_response):
    history = load_chat_history()
    idx = history[-1]["index"] + 1 if history else 1
    history.append({"index": idx, "user": user_query.strip(), "bot": bot_response.strip()})
    save_json_file(CHAT_HISTORY_FILE, history)

def load_summary():
    return load_json_file(SUMMARY_FILE)

def append_summary(new_point):
    summary = load_summary()
    idx = summary[-1]["index"] + 1 if summary else 1
    summary.append({"index": idx, "summary": new_point.strip()})
    save_json_file(SUMMARY_FILE, summary)

# === Embedding & Context ===
def get_embedding(query):
    return [0.0] * 768  # Replace with real embedding

def summarize_text(text, max_words=50):
    doc = nlp(text)
    keywords = [token.text for token in doc if token.is_alpha and not token.is_stop]
    return " ".join(keywords[:max_words])

def get_trimmed_summary(limit=3):
    summary_data = load_summary()
    trimmed = summary_data[-limit:] if len(summary_data) > limit else summary_data
    reduced = [summarize_text(item["summary"], max_words=30) for item in trimmed]
    return "\n".join([f"{item['index']}. {reduced[i]}" for i, item in enumerate(trimmed)])

def query_pinecone(query, top_k=5, max_chars=1000):
    vector = get_embedding(query)
    result = index.query(vector=vector, top_k=top_k, include_metadata=True)
    chunks = []
    if "matches" in result:
        for match in result["matches"]:
            metadata = match.get("metadata", {})
            if "text" in metadata:
                trimmed = summarize_text(metadata["text"], max_words=50)
                chunks.append(trimmed)
    return "\n".join(chunks)[:max_chars]

# === Gemini API ===
def get_gemini_response(prompt):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={GOOGLE_API_KEY}"
    headers = {"Content-Type": "application/json"}
    data = {"contents": [{"parts": [{"text": prompt}]}]}
    try:
        r = requests.post(url, headers=headers, json=data)
        r.raise_for_status()
        return r.json()['candidates'][0]['content']['parts'][0]['text']
    except Exception as e:
        print(f"Gemini Error: {e}")
        return None

# === Main Logic ===
def generate_response(query, source, name, role, description):
    summary_text = get_trimmed_summary()
    context_text = query_pinecone(query)

    system_prompt = f"""
You are {name}, a {role} built by IQ TechMax. You are designed to respond to user questions with helpful and accurate answers strictly based on the provided context. Your character: {description}.

User query: {query}
Source: {source}
Summary:
{summary_text if summary_text else "None yet"}
Context:
{context_text}

Instructions:
1. If related to a past chat:
   - Refer to the summary.
   - Use history if needed.
   - Link back if summary index is referenced.
2. If first query:
   - Greet the user as {name}.
   - Use context to help.
3. Always return a JSON with:
   - "response": final answer
   - "updatedSummary": summary in form "User asked X, was told Y"
4. If unclear, ask for clarification.
5. If no answer in context:
   - Respond: "I don't have relevant info..."
6. Keep the tone conversational and natural.
""".strip()

    input_tokens = estimate_token_count(system_prompt)
    response_text = get_gemini_response(system_prompt)

    if response_text:
        output_tokens = estimate_token_count(response_text)
        total_tokens = input_tokens + output_tokens
        print(f"\n[Token Usage] Input: {input_tokens}, Output: {output_tokens}, Total: {total_tokens}\n")

        try:
            cleaned = response_text.replace("```json", "").replace("```", "").strip()
            response_json = json.loads(cleaned)
            bot_reply = response_json.get("response", "").strip()
            summary_point = response_json.get("updatedSummary", "").strip()
            append_summary(summary_point)
            append_chat_history(query, bot_reply)
            return bot_reply
        except Exception as e:
            print(f"Parse Error: {e}")
            append_chat_history(query, response_text)
            return response_text
    else:
        append_chat_history(query, "No response")
        return "Sorry, no response from Gemini."

# === Chat CLI ===
def start_chat():
    print("Start chatting with KTM. Type 'exit' to stop.")
    while True:
        user_input = input("User: ")
        if user_input.lower() in ["exit", "quit"]:
            print("Chat ended.")
            break
        response = generate_response(
            query=user_input,
            source="text_chat",
            name="ktm",
            role="AI Assistant",
            description="A helpful and strict assistant with access only to provided context."
        )
        print("Bot:", response)

# === Run Chat ===
if __name__ == "__main__":
    start_chat()
