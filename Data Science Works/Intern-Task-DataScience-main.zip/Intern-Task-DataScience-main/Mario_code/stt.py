import whisper
import google.generativeai as genai
import sounddevice as sd
import scipy.io.wavfile as wav
import os
import time

# -------------------------------
# CONFIGURATION
# -------------------------------
DURATION = 5  # seconds per voice input
OUTPUT_FILE = "recorded.wav"
GEMINI_API_KEY = "AIzaSyAuBb7uVWr2MnJhb8QpJq6K2D29yzC7Kt4"  # <-- Replace with your Gemini API key

# -------------------------------
# SETUP GEMINI
# -------------------------------
genai.configure(api_key=GEMINI_API_KEY)
chat_model = genai.GenerativeModel('gemini-pro')
chat_session = chat_model.start_chat(history=[])

# -------------------------------
# RECORD AUDIO FROM MIC
# -------------------------------
def record_audio(duration, filename):
    print(f"\n🎤 Speak now ({duration} seconds)...")
    fs = 16000
    audio = sd.rec(int(duration * fs), samplerate=fs, channels=1, dtype='int16')
    sd.wait()
    wav.write(filename, fs, audio)
    print("✅ Recording complete.")

# -------------------------------
# TRANSCRIBE WITH WHISPER
# -------------------------------
def transcribe_audio(filename):
    model = whisper.load_model("base")  # You can change to "medium" or "small"
    print("🔍 Transcribing and translating from Tamil...")
    result = model.transcribe(filename, task="translate", language="en")
    return result['text']

# -------------------------------
# CHATBOT REPLY FROM GEMINI
# -------------------------------
def get_gemini_response(prompt):
    try:
        response = chat_session.send_message(prompt)
        return response.text.strip()
    except Exception as e:
        return f"⚠️ Error: {e}"

# -------------------------------
# MAIN LOOP
# -------------------------------
def main():
    print("🧠 Tamil Voice Chatbot with Whisper + Gemini")
    print("Press Ctrl+C to exit.\n")

    while True:
        try:
            record_audio(DURATION, OUTPUT_FILE)
            user_input = transcribe_audio(OUTPUT_FILE)
            print(f"\n🗣️ You said (translated): {user_input}")

            if user_input.strip() == "":
                print("⚠️ Empty input. Please speak clearly.")
                continue

            response = get_gemini_response(user_input)
            print(f"\n🤖 Gemini says: {response}\n")

            time.sleep(1)  # short pause between interactions
        except KeyboardInterrupt:
            print("\n👋 Exiting chatbot. Goodbye!")
            break
        except Exception as e:
            print(f"⚠️ Unexpected error: {e}")

if __name__ == "__main__":
    main()