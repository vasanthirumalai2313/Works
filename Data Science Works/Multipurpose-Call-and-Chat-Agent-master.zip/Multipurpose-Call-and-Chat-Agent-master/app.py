# from flask import Flask, render_template, request, jsonify
# from chat import chat
# from flask_cors import CORS 

# app = Flask(__name__)
# CORS(app)

# @app.route("/")
# def index():
#     return render_template("index.html")

# @app.route("/iqbot", methods=["POST"])
# def chat_api():
#     try:
#         data = request.get_json(force=True)
#         user_input = data.get("message", "")
#     except Exception as e:
#         return jsonify({"response": f"Invalid JSON input: {str(e)}"}), 400

#     if not user_input:
#         return jsonify({"response": "Invalid input!"}), 400

#     try:
#         response = chat(user_input)
#         return jsonify({"response": response})
#     except Exception as e:
#         return jsonify({"response": f"An error occurred: {str(e)}"}), 500

# if __name__ == "__main__":
#     app.run(host="0.0.0.0", port=8000)

from flask import Flask, render_template, request, jsonify
from chat import chat
from flask_cors import CORS 

app = Flask(__name__)
CORS(app)

@app.route("/")
def index():
    # Change the template name if needed.
    return render_template("call.html")

@app.route("/iqbot", methods=["POST"])
def chat_api():
    try:
        data = request.get_json(force=True)
        user_input = data.get("message", "")
    except Exception as e:
        return jsonify({"response": f"Invalid JSON input: {str(e)}"}), 400

    if not user_input:
        return jsonify({"response": "Invalid input!"}), 400

    try:
        response = chat(user_input)
        return jsonify({"response": response})
    except Exception as e:
        return jsonify({"response": f"An error occurred: {str(e)}"}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
 