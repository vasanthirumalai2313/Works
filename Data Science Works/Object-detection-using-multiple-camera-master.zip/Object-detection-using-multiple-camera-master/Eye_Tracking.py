import cv2
import torch
import numpy as np
from PIL import Image
from gazelle.model import get_gazelle_model
from gazelle.utils import visualize_heatmap

# Load GazeLLE model and transform
model, transform = get_gazelle_model("gazelle_dinov2_vitl14_inout")
checkpoint_path = "checkpoints/gazelle_dinov2_vitl14_inout.pt"
model.load_gazelle_state_dict(torch.load(checkpoint_path, weights_only=True))
model.eval()

device = "cuda" if torch.cuda.is_available() else "cpu"
model.to(device)

# Open webcam
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Convert BGR to RGB PIL image
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    pil_image = Image.fromarray(frame_rgb)

    # Transform and prepare input
    input_tensor = transform(pil_image).unsqueeze(0).to(device)
    input_data = {
        "images": input_tensor,
        "bboxes": [[None]]  # None means no bounding box, single person scenario
    }

    # Run inference
    with torch.no_grad():
        output = model(input_data)

    predicted_heatmap = output["heatmap"][0][0].cpu()
    predicted_inout = output["inout"][0][0].item() if output["inout"] is not None else None

    # Visualize heatmap on original image
    heatmap_img = visualize_heatmap(pil_image, predicted_heatmap)
    heatmap_bgr = cv2.cvtColor(np.array(heatmap_img), cv2.COLOR_RGB2BGR)

    # Overlay in/out score text
    if predicted_inout is not None:
        cv2.putText(heatmap_bgr, f"In Frame Score: {predicted_inout:.2f}", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)

    # Show the result
    cv2.imshow("GazeLLE Live Gaze Heatmap", heatmap_bgr)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
