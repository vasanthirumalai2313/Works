import os
import json
import time
import requests
import imaplib
import email
from email.header import decode_header
from bs4 import BeautifulSoup
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
from langdetect import detect
from pinecone import Pinecone, ServerlessSpec

# === Configuration ===
GMAIL_APP_PASSWORD = "nidf pzlh ayra nexn"
GMAIL_ADDRESS = "tangiro248@gmail.com"
GOOGLE_API_KEY ="AIzaSyDHP46bXE-RcjKCofW4Oa-AuR70SqVMbFQ"
SENDGRID_API_KEY = "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"  # <-- put your actual SendGrid API key here
PINECONE_API_KEY = "pcsk_5zopuj_2KQTvFYBxwsahjo46HDCFy6ADfBK3PuFg3PjXJeHLfKe2Dw5bMrUc1ypfdhKirH"
INDEX_NAME = "iq-bot-demo1"

# === Pinecone Setup ===
pc = Pinecone(api_key=PINECONE_API_KEY)

def initialize_pinecone_index():
    if INDEX_NAME not in pc.list_indexes().names():
        pc.create_index(
            name=INDEX_NAME,
            dimension=768,
            metric="cosine",
            spec=ServerlessSpec(cloud="aws", region="us-east-1")
        )
    return pc.Index(INDEX_NAME)

index = initialize_pinecone_index()

# === File Utilities ===
CHAT_HISTORY_FILE = "chat_history.txt"
SUMMARY_FILE = "chat_summary.txt"

def load_json_file(file_path):
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return []
    return []

def save_json_file(file_path, data):
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

# === Chat History ===
def load_chat_history():
    return load_json_file(CHAT_HISTORY_FILE)

def append_chat_history(user_query, bot_response):
    history = load_chat_history()
    current_index = history[-1]["index"] + 1 if history else 1
    history.append({"index": current_index, "user": user_query.strip(), "bot": bot_response.strip()})
    save_json_file(CHAT_HISTORY_FILE, history)

# === Summary ===
def load_summary():
    return load_json_file(SUMMARY_FILE)

def append_summary(new_summary_point):
    summary = load_summary()
    current_index = summary[-1]["index"] + 1 if summary else 1
    summary.append({"index": current_index, "summary": new_summary_point.strip()})
    save_json_file(SUMMARY_FILE, summary)

# === Pinecone Retrieval ===
def get_embedding(query):
    return [0.0] * 768  # Replace with real embedding logic

def query_pinecone(query):
    vector = get_embedding(query)
    result = index.query(vector=vector, top_k=5, include_metadata=True)
    context = [match["metadata"].get("text", "") for match in result.get("matches", [])]
    return "\n".join(context)

# === Gemini API Call ===
def get_gemini_response(prompt):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={GOOGLE_API_KEY}"
    headers = {"Content-Type": "application/json"}
    data = {"contents": [{"parts": [{"text": prompt}]}]}
    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        result = response.json()
        return result['candidates'][0]['content']['parts'][0]['text']
    except Exception as e:
        print(f"[Gemini Error]: {e}")
        return None

# === Send Email ===
def send_email(subject, content, to_email):
    message = Mail(
        from_email=GMAIL_ADDRESS,
        to_emails=to_email,
        subject=subject,
        plain_text_content=content
    )
    try:
        sg = SendGridAPIClient(SENDGRID_API_KEY)
        response = sg.send(message)
        print(f"[Email Sent] To: {to_email} (Status: {response.status_code})")
    except Exception as e:
        print(f"[SendGrid Error]: {e}")

# === AI Response Generator ===
def generate_response(user_query):
    try:
        detected_language = detect(user_query)
    except Exception as e:
        print(f"[Language Detection Error]: {e}")
        detected_language = "en"

    summary_data = load_summary()
    current_summary = "\n".join([f"{item['index']}. {item['summary']}" for item in summary_data])
    context = query_pinecone(user_query)

    system_prompt = f"""
You are KTM, a multilingual AI Assistant replying to customer emails professionally.

Your task:
1. Detect the language: "{detected_language.upper()}"
2. Reply in that same language.
3. Format your reply as a complete, professional email with:
   - Greeting (Dear Customer)
   - Clear helpful body
   - Sign-off (Best regards, KTM Support Team)

Query: {user_query}
Summary: {current_summary if current_summary else "None yet"}
Context: {context}

Respond in JSON format only:
{{
  "response": "Full professional email response.",
  "updatedSummary": "Short summary of the response for chat memory."
}}
"""

    response_text = get_gemini_response(system_prompt)
    if response_text:
        try:
            response_json = json.loads(response_text.replace("```json", "").replace("```", "").strip())
            final_reply = response_json.get("response", "").strip()
            new_summary_point = response_json.get("updatedSummary", "").strip()

            append_summary(new_summary_point)
            append_chat_history(user_query, final_reply)
            return final_reply
        except Exception as e:
            print(f"[Parsing Error]: {e}")
            return response_text
    else:
        return "Sorry, no response from Gemini."

# === Email Monitoring ===
def clean_text(text):
    return ''.join(c if c.isprintable() else ' ' for c in text).strip()

def check_inbox():
    mail = imaplib.IMAP4_SSL("imap.gmail.com")
    mail.login(GMAIL_ADDRESS, GMAIL_APP_PASSWORD)
    mail.select("inbox")
    status, messages = mail.search(None, 'UNSEEN')
    email_ids = messages[0].split()

    for email_id in email_ids:
        _, msg_data = mail.fetch(email_id, "(RFC822)")
        for response_part in msg_data:
            if isinstance(response_part, tuple):
                msg = email.message_from_bytes(response_part[1])
                subject, encoding = decode_header(msg["Subject"])[0]
                subject = subject.decode(encoding) if isinstance(subject, bytes) else subject
                from_email = msg.get("From")
                sender_email = email.utils.parseaddr(from_email)[1]

                body = ""
                if msg.is_multipart():
                    for part in msg.walk():
                        content_type = part.get_content_type()
                        if content_type == "text/plain":
                            body = part.get_payload(decode=True).decode(errors="ignore")
                            break
                else:
                    body = msg.get_payload(decode=True).decode(errors="ignore")

                body_clean = BeautifulSoup(body, "html.parser").get_text()
                print(f"\n New Email from: {sender_email} | Subject: {subject}")
                print(f" Content:\n{body_clean.strip()[:200]}...\n")

                response = generate_response(body_clean.strip())
                send_email(subject=f"Re: {subject}", content=response, to_email=sender_email)

                mail.store(email_id, '+FLAGS', '\\Seen')

    mail.logout()

# === Run Loop ===
def run_auto_loop(interval=10):
    print(" AI Email Auto-Responder Running (Ctrl+C to stop)...\n")
    try:
        while True:
            check_inbox()
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\n[Stopped by user]")

if __name__ == "__main__":
    run_auto_loop()
