import os
import uuid
import json
import math
from typing import List, Optional, Dict, Any

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import google.generativeai as genai
import numpy as np

# ----------------------------
# Setup
# ----------------------------
load_dotenv()
API_KEY = os.getenv("GEMINI_API_KEY")
if not API_KEY:
    raise RuntimeError("Set GEMINI_API_KEY in .env")

genai.configure(api_key=API_KEY)

LLM_MODEL = "models/gemini-1.5-flash"
EMB_MODEL = "models/text-embedding-004"

app = FastAPI(title="AI Talent Broker (Events)")

# ----------------------------
# Storage (in-memory + simple JSON persistence)
# ----------------------------

DATA_FILE = "broker_data.json"

class TalentRecord(BaseModel):
    id: str
    name: str
    type: str
    style: Optional[str] = None
    location: Optional[str] = None
    price_min: Optional[int] = None
    price_max: Optional[int] = None
    bio: Optional[str] = None
    links: List[str] = Field(default_factory=list)
    # embedding not serialized directly (large); we store separately
    embedding: Optional[List[float]] = None

class EventRecord(BaseModel):
    id: str
    event_type: Optional[str] = None
    talent_type: Optional[str] = None
    style: Optional[str] = None
    location: Optional[str] = None
    audience: Optional[str] = None
    budget: Optional[int] = None
    date: Optional[str] = None
    notes: Optional[str] = None
    embedding: Optional[List[float]] = None

# In-memory stores
TALENTS: Dict[str, TalentRecord] = {}
EVENTS: Dict[str, EventRecord] = {}

def save_data():
    blob = {
        "talents": [t.model_dump(exclude={"embedding"}) for t in TALENTS.values()],
        "events": [e.model_dump(exclude={"embedding"}) for e in EVENTS.values()],
        "talent_embeddings": {tid: TALENTS[tid].embedding for tid in TALENTS if TALENTS[tid].embedding is not None},
        "event_embeddings": {eid: EVENTS[eid].embedding for eid in EVENTS if EVENTS[eid].embedding is not None},
    }
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(blob, f, ensure_ascii=False, indent=2)

def load_data():
    if not os.path.exists(DATA_FILE):
        return
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        blob = json.load(f)
    for t in blob.get("talents", []):
        rec = TalentRecord(**t)
        TALENTS[rec.id] = rec
    for e in blob.get("events", []):
        rec = EventRecord(**e)
        EVENTS[rec.id] = rec
    # restore embeddings
    for tid, emb in blob.get("talent_embeddings", {}).items():
        if tid in TALENTS:
            TALENTS[tid].embedding = emb
    for eid, emb in blob.get("event_embeddings", {}).items():
        if eid in EVENTS:
            EVENTS[eid].embedding = emb

load_data()

# ----------------------------
# Utilities
# ----------------------------

def embed_text(text: str) -> List[float]:
    """Return a normalized embedding vector using Gemini embeddings."""
    if not text or not text.strip():
        return []
    result = genai.embed_content(model=EMB_MODEL, content=text)
    vec = result["embedding"]
    # normalize for cosine similarity
    norm = math.sqrt(sum(v*v for v in vec)) or 1.0
    return [v / norm for v in vec]

def talent_to_corpus(t: TalentRecord) -> str:
    return "\n".join([
        f"Name: {t.name}",
        f"Type: {t.type}",
        f"Style: {t.style or ''}",
        f"Location: {t.location or ''}",
        f"Price Range: {t.price_min or ''}-{t.price_max or ''}",
        f"Bio: {t.bio or ''}",
        f"Links: {', '.join(t.links) if t.links else ''}",
    ])

def event_to_query_corpus(e: EventRecord) -> str:
    return "\n".join([
        f"Event Type: {e.event_type or ''}",
        f"Talent Type: {e.talent_type or ''}",
        f"Style: {e.style or ''}",
        f"Location: {e.location or ''}",
        f"Audience: {e.audience or ''}",
        f"Budget: {e.budget or ''}",
        f"Date: {e.date or ''}",
        f"Notes: {e.notes or ''}",
    ])

def cosine_sim(a: List[float], b: List[float]) -> float:
    if not a or not b:
        return 0.0
    # inputs are normalized; cosine is dot product
    return float(np.dot(np.array(a, dtype=np.float32), np.array(b, dtype=np.float32)))

# ----------------------------
# LLM Parsers (free-text → structured JSON)
# ----------------------------

def llm_parse_talent(free_text: str) -> Dict[str, Any]:
    prompt = f"""
You are an expert data extractor for an event talent marketplace.
Extract structured fields from the TALENT description below.
Return ONLY a compact JSON object with keys:
name, type, style, location, price_min, price_max, bio, links (array of URLs if present).
Missing numeric fields should be null (not strings). Price values should be integers in INR.

TALENT:
\"\"\"{free_text.strip()}\"\"\"
"""
    model = genai.GenerativeModel(LLM_MODEL)
    resp = model.generate_content(prompt)
    # Try to locate JSON in the response
    text = resp.text.strip()
    # A simple safe parse attempt
    try:
        data = json.loads(text)
        if not isinstance(data.get("links", []), list):
            data["links"] = []
        return data
    except Exception:
        # Fallback: ask the model to output raw JSON again
        prompt2 = f"""
Return ONLY valid JSON (no extra text) for the same request:

{prompt}
"""
        resp2 = model.generate_content(prompt2)
        try:
            return json.loads(resp2.text.strip())
        except Exception:
            # last resort minimal
            return {
                "name": None, "type": None, "style": None, "location": None,
                "price_min": None, "price_max": None, "bio": free_text.strip(), "links": []
            }

def llm_parse_event(free_text: str) -> Dict[str, Any]:
    prompt = f"""
You are an expert data extractor for an event talent marketplace.
Extract structured fields from the EVENT REQUIREMENT below.
Return ONLY a compact JSON object with keys:
event_type, talent_type, style, location, audience, budget, date, notes.
Budget should be a single integer INR amount if a range is given, pick the midpoint.
Date can be free-form (e.g., 'Oct 12 2025' or 'mid-September'), else null.

EVENT:
\"\"\"{free_text.strip()}\"\"\"
"""
    model = genai.GenerativeModel(LLM_MODEL)
    resp = model.generate_content(prompt)
    text = resp.text.strip()
    try:
        return json.loads(text)
    except Exception:
        # Fallback one more time
        prompt2 = f"""
Return ONLY valid JSON (no extra text) for the same request:

{prompt}
"""
        resp2 = model.generate_content(prompt2)
        try:
            return json.loads(resp2.text.strip())
        except Exception:
            return {
                "event_type": None, "talent_type": None, "style": None, "location": None,
                "audience": None, "budget": None, "date": None, "notes": free_text.strip()
            }

# ----------------------------
# API Schemas
# ----------------------------

class TalentIn(BaseModel):
    # Either fill structured fields OR provide free_text; both are allowed
    name: Optional[str] = None
    type: Optional[str] = None
    style: Optional[str] = None
    location: Optional[str] = None
    price_min: Optional[int] = None
    price_max: Optional[int] = None
    bio: Optional[str] = None
    links: Optional[List[str]] = None
    free_text: Optional[str] = None

class EventIn(BaseModel):
    event_type: Optional[str] = None
    talent_type: Optional[str] = None
    style: Optional[str] = None
    location: Optional[str] = None
    audience: Optional[str] = None
    budget: Optional[int] = None
    date: Optional[str] = None
    notes: Optional[str] = None
    free_text: Optional[str] = None

class MatchResponse(BaseModel):
    event_id: str
    top_k: int
    results: List[Dict[str, Any]]

# ----------------------------
# Routes
# ----------------------------

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/talents", response_model=TalentRecord)
def add_talent(payload: TalentIn):
    # If free_text provided, parse with LLM
    if payload.free_text and payload.free_text.strip():
        parsed = llm_parse_talent(payload.free_text)
        name = parsed.get("name") or payload.name or "Unnamed"
        t = TalentRecord(
            id=str(uuid.uuid4()),
            name=name,
            type=parsed.get("type") or payload.type or "Performer",
            style=parsed.get("style") or payload.style,
            location=parsed.get("location") or payload.location,
            price_min=parsed.get("price_min") or payload.price_min,
            price_max=parsed.get("price_max") or payload.price_max,
            bio=parsed.get("bio") or payload.bio,
            links=parsed.get("links") or payload.links or [],
        )
    else:
        # structured input
        if not payload.name or not payload.type:
            raise HTTPException(status_code=400, detail="name and type are required if free_text not provided")
        t = TalentRecord(
            id=str(uuid.uuid4()),
            name=payload.name,
            type=payload.type,
            style=payload.style,
            location=payload.location,
            price_min=payload.price_min,
            price_max=payload.price_max,
            bio=payload.bio,
            links=payload.links or [],
        )

    # Build embedding
    corpus = talent_to_corpus(t)
    t.embedding = embed_text(corpus)

    TALENTS[t.id] = t
    save_data()
    return t

@app.get("/talents", response_model=List[TalentRecord])
def list_talents():
    return list(TALENTS.values())

@app.post("/events", response_model=EventRecord)
def add_event(payload: EventIn):
    # If free_text provided, parse with LLM
    if payload.free_text and payload.free_text.strip():
        parsed = llm_parse_event(payload.free_text)
        e = EventRecord(
            id=str(uuid.uuid4()),
            event_type=parsed.get("event_type") or payload.event_type,
            talent_type=parsed.get("talent_type") or payload.talent_type,
            style=parsed.get("style") or payload.style,
            location=parsed.get("location") or payload.location,
            audience=parsed.get("audience") or payload.audience,
            budget=parsed.get("budget") or payload.budget,
            date=parsed.get("date") or payload.date,
            notes=parsed.get("notes") or payload.notes,
        )
    else:
        e = EventRecord(
            id=str(uuid.uuid4()),
            event_type=payload.event_type,
            talent_type=payload.talent_type,
            style=payload.style,
            location=payload.location,
            audience=payload.audience,
            budget=payload.budget,
            date=payload.date,
            notes=payload.notes,
        )

    # Build embedding
    q = event_to_query_corpus(e)
    e.embedding = embed_text(q)

    EVENTS[e.id] = e
    save_data()
    return e

@app.get("/events", response_model=List[EventRecord])
def list_events():
    return list(EVENTS.values())

@app.get("/match/{event_id}", response_model=MatchResponse)
def match_event(event_id: str, top_k: int = 5):
    if event_id not in EVENTS:
        raise HTTPException(status_code=404, detail="event not found")
    e = EVENTS[event_id]
    if not e.embedding:
        e.embedding = embed_text(event_to_query_corpus(e))

    # score all talents
    scored = []
    for t in TALENTS.values():
        sim = cosine_sim(e.embedding, t.embedding or [])
        # Light re-ranking rules (budget, type, style, location preference)
        bonus = 0.0
        if e.talent_type and t.type:
            bonus += 0.05 if e.talent_type.lower() in t.type.lower() else 0.0
        if e.style and t.style:
            bonus += 0.05 if e.style.lower() in t.style.lower() else 0.0
        if e.location and t.location:
            bonus += 0.03 if e.location.lower() == t.location.lower() else 0.0
        if e.budget and t.price_min and t.price_max:
            if t.price_min <= e.budget <= t.price_max:
                bonus += 0.07
        final_score = float(sim + bonus)
        scored.append((final_score, t))

    scored.sort(key=lambda x: x[0], reverse=True)
    top = scored[: max(1, top_k)]

    # Ask LLM to produce a short broker-style explanation
    explainer_prompt = f"""
You are an AI broker. Given an EVENT and CANDIDATES with scores, briefly justify the top matches.
Be concise and useful for an event organizer.

EVENT:
{event_to_query_corpus(e)}

CANDIDATES:
{[{'name': t.name, 'type': t.type, 'style': t.style, 'location': t.location, 'price_min': t.price_min, 'price_max': t.price_max, 'score': round(s,3)} for s, t in top]}
"""
    model = genai.GenerativeModel(LLM_MODEL)
    reasoning = model.generate_content(explainer_prompt).text

    results = []
    for score, t in top:
        results.append({
            "talent_id": t.id,
            "name": t.name,
            "type": t.type,
            "style": t.style,
            "location": t.location,
            "price_min": t.price_min,
            "price_max": t.price_max,
            "score": round(score, 3),
        })

    return MatchResponse(event_id=event_id, top_k=top_k, results=results | [{"explanation": reasoning}])

# Python 3.9 compatibility for dict union
try:
    {} | {}
except TypeError:
    # define a tiny helper for py<3.9 environments
    def dict_union(a, b):
        c = a.copy()
        c.update(b)
        return c
    # patch the return in match_event
    import inspect
    import textwrap
    src = inspect.getsource(match_event)
    src = src.replace("results = results | [{\"explanation\": reasoning}]", "results = dict_union({'list': results}, {'explanation': reasoning})['list']")
    # This is only to keep the single-file example 3.8-friendly if needed
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
